-- ************************************************************************** --
-- *  videotpg                                                              * --
-- *------------------------------------------------------------------------* --
-- *  Module :  TPG_LIB-RTL                                                 * --
-- *    File :  tpg_lib.vhd                                                 * --
-- *    Date :  2022-03-16                                                  * --
-- *     Rev :  0.2                                                         * --
-- *  Author :  SS                                                          * --
-- *------------------------------------------------------------------------* --
-- *  package containing types, constants and addresses                     * --
-- *  for the videotpg core.                                                * --
-- *------------------------------------------------------------------------* --
-- *  0.1  |  2021-07-26  |  SS  |  Initial release                         * --
-- *  0.2  |  2022-03-16  |  SS  |  Added revision and core level constants * --
-- ************************************************************************** --


library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;


--------------------------------------------------------------------------------
--  TPG_LIB package
--------------------------------------------------------------------------------

package tpg_lib is

    -- TPG control information (axislave -> pattern generator)
    type TPG_CONTROL_T is record
        grab_en         : std_logic;                        -- aquisition enable
        img_width       : std_logic_vector(31 downto 0);    -- width
        img_height      : std_logic_vector(31 downto 0);    -- height
        offs_x          : std_logic_vector(31 downto 0);    -- offset x
        offs_y          : std_logic_vector(31 downto 0);    -- offset y
        pixfmt          : std_logic_vector(31 downto 0);    -- pixel format
        gap_x           : std_logic_vector(31 downto 0);    -- Additional gap between lines
        gap_y           : std_logic_vector(31 downto 0);    -- Additional gap between frames
        chunk_ctrl      : std_logic_vector(31 downto 0);    -- Chunk control register (bit 31: activate extended chunk mode, bit 0: active framecounter chunk (not used))
    end record TPG_CONTROL_T;

    -- TPG status information(pattern generator -> axislave)
    -- not used right now
    type TPG_STATUS_T is record
        -- add custom signals here
        void            : std_logic;                        -- NOTE: Just a placeholder
    end record TPG_STATUS_T;

    -- chunk data array
    type CHUNK_DATA_ARRAY is array (integer range <>) of std_logic_vector(7 downto 0);

    -- Assign vector with byte enables
    function assign_be(orig : std_logic_vector;
                       val  : std_logic_vector;
                       be   : std_logic_vector) return std_logic_vector;

    -- Convert natural value to N bit std_logic_vector
    function aN(addr : natural; n : natural) return std_logic_vector;

    -- IP core revision and identification (updated automatically from Makefile!)
    constant REV_MAJOR          : integer                       := 1;
    constant REV_MINOR          : integer                       := 0;
    constant REV_SUBMINOR       : integer                       := 3;
    constant REV_DATE           : std_logic_vector(31 downto 0) := x"20231115";
    constant REV_VERSION        : std_logic_vector(31 downto 0) := std_logic_vector(to_unsigned(REV_MAJOR,     8) &
                                                                                    to_unsigned(REV_MINOR,     8) &
                                                                                    to_unsigned(REV_SUBMINOR, 16));
    constant REV_ID             : std_logic_vector(31 downto 0) := x"A5A5000D";
    constant CORE_LEVEL         : natural                       := 0;

    -- Pixel formats
    constant PIX_MONO8      : std_logic_vector(31 downto 0) := x"01080001";
    constant PIX_MONO16     : std_logic_vector(31 downto 0) := x"01100007";
    constant PIX_RGB8       : std_logic_vector(31 downto 0) := x"02180014";

    constant CHUNKID_IMG    : std_logic_vector(31 downto 0) := x"617D18DB"; -- ID of image chunk
    constant CHUNKID_FC     : std_logic_vector(31 downto 0) := x"8C0F1CD8"; -- ID of frame counter chunk

    -- Default register values
    constant DEF_CONTROL        : std_logic_vector(31 downto 0) := x"00000000";
    constant DEF_IMG_WIDTH      : std_logic_vector(31 downto 0) := x"00000400";
    constant DEF_IMG_HEIGHT     : std_logic_vector(31 downto 0) := x"00000400";
    constant DEF_OFFS_X         : std_logic_vector(31 downto 0) := x"00000000";
    constant DEF_OFFS_Y         : std_logic_vector(31 downto 0) := x"00000000";
    constant DEF_PIXFMT         : std_logic_vector(31 downto 0) :=   PIX_MONO8;
    constant DEF_GAP_X          : std_logic_vector(31 downto 0) := x"000004DF";
    constant DEF_GAP_Y          : std_logic_vector(31 downto 0) := x"00000090";
    constant DEF_GPIO_IN        : std_logic_vector(31 downto 0) := x"00000000";
    constant DEF_GPIO_OUT       : std_logic_vector(31 downto 0) := x"00000000";
    constant DEF_CHUNK_CTRL     : std_logic_vector(31 downto 0) := x"00000000";

    -- AXI4-Lite slave register map
    -- Register addresses must be equal to the corresponding addresses in the firmware
    constant ADDR_WIDTH         : natural                                   := 8;
    -- ... common status
    constant ADDR_GCSR          : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"00";
    constant ADDR_IMG_WIDTH     : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"04";
    constant ADDR_IMG_HEIGHT    : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"08";
    constant ADDR_OFFS_X        : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"0C";
    constant ADDR_OFFS_Y        : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"10";
    constant ADDR_PIXFMT        : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"18";
    constant ADDR_GAP_X         : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"1C";
    constant ADDR_GAP_Y         : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"20";
    constant ADDR_GPIO_IN       : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"24";
    constant ADDR_GPIO_OUT      : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"28";
    constant ADDR_CHUNK_CTRL    : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"2C";      -- Chunk control register adress
    constant ADDR_CHUNKID_IMG   : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"30";      -- Image chunk id register adress
    constant ADDR_CHUNKID_FC    : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"34";      -- Frame counter chunk id register adress
    constant ADDR_TPG_MODE      : std_logic_vector(ADDR_WIDTH - 1 downto 0) := x"38";

end package tpg_lib;


--------------------------------------------------------------------------------
--  TPG_LIB package body
--------------------------------------------------------------------------------

package body tpg_lib is

    -- Assign vector with byte enables
    function assign_be(orig : std_logic_vector;
                       val  : std_logic_vector;
                       be   : std_logic_vector) return std_logic_vector is
        variable ret    : std_logic_vector(orig'range)  := orig;
    begin
        for i in 0 to ((orig'length / 8) - 1) loop
            if be(i) = '1' then
                ret((i * 8) + 7 downto i * 8) := val((i * 8) + 7 downto i * 8);
            end if;
        end loop;
        return ret;
    end function assign_be;

    -- Convert natural value to N bit std_logic_vector
    function aN(addr : natural; n : natural) return std_logic_vector is
    begin
        return std_logic_vector(to_unsigned(addr, n));
    end function aN;

end package body tpg_lib;