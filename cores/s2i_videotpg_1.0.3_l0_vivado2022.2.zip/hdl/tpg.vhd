-- ************************************************************************** --
-- *  videotpg                                                              * --
-- *------------------------------------------------------------------------* --
-- *  Module :  TPG-RTL                                                     * --
-- *    File :  tpg.vhd                                                     * --
-- *    Date :  2021-09-07                                                  * --
-- *     Rev :  0.2                                                         * --
-- *  Author :  SS                                                          * --
-- *------------------------------------------------------------------------* --
-- *  test pattern generator                                                * --
-- *------------------------------------------------------------------------* --
-- *  0.1  |  2021-07-26  |  SS  |  Initial release                         * --
-- *  0.2  |  2021-09-07  |  SS  |  Fixed framerate for multi pixel mode    * --
-- *       |              |      |  Added extened chunk capability to       * --
-- *       |              |      |  multi pixel mode                        * --
-- ************************************************************************** --


library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     work.tpg_lib.all;


entity tpg is
    generic(TPG_OUT_MODE : natural range 0 to 1 := 0);                             		-- '0': 1 Pixel per clock, '1': several Pixel per clock
    port   (sys_rst      : in   std_logic;                                              -- todo: reset?
            -- control and status interface
            tpg_control  : in   TPG_CONTROL_T;
            tpg_status   : out  TPG_STATUS_T;
            -- GEV Stream Channel interface
            gev_scc      : in   std_logic;                                              -- Stream channel closed
            -- Framebuffer interface
            fb_clk       : in   std_logic;                                              -- Interface clock
            fb_rst       : in   std_logic;                                              -- Synchronous reset
            fb_frame     : out  std_logic;                                              -- Frame valid
            fb_dv        : out  std_logic;                                              -- Data valid
            fb_data      : out  std_logic_vector(63 downto 0);                          -- Pixel data
            fb_width     : out  std_logic_vector( 6 downto 0));                         -- Memory interface data width

end entity tpg;

architecture rtl of tpg is

    -- Signals -----------------------------------------------------------------

    -- Control signals
    signal ctrl_grab_en     : std_logic                     := '0';
    signal ctrl_img_width   : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_img_height  : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_offs_x      : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_offs_y      : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_pixfmt      : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_gap_x       : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_gap_y       : std_logic_vector(31 downto 0) := (others => '0');
    signal ctrl_chunk_ctrl  : std_logic_vector(31 downto 0) := (others => '0');

    -- Test pattern generator
    signal tst_px_width     : std_logic_vector( 2 downto 0) := (others => '0');         -- Pixelbreite/Datenbreite Memory Interface
    signal tst_data         : std_logic_vector(63 downto 0) := (others => '0');         -- Pixel data
    signal tst_frame        : std_logic                     := '0';                     -- Frame valid
    signal tst_frame_r      : std_logic                     := '0';
    signal tst_line         : std_logic                     := '0';                     -- Line valid
    signal tst_hcnt         : unsigned        (15 downto 0) := (others => '0');         -- Column counter
    signal tst_vcnt         : unsigned        (15 downto 0) := (others => '0');         -- Line counter
    signal tst_shift        : unsigned        ( 7 downto 0) := (others => '0');         -- Pixel value offset
    signal tst_hstart       : unsigned        (15 downto 0) := (others => '0');         -- First clock cycle of a line
    signal tst_hend         : unsigned        (15 downto 0) := (others => '0');         -- Last clock cycle of a line
    signal tst_hmax         : unsigned        (15 downto 0) := (others => '0');         -- Number of clocks per line - 1
    signal tst_vstart       : unsigned        (15 downto 0) := (others => '0');         -- First line of a frame
    signal tst_vend         : unsigned        (15 downto 0) := (others => '0');         -- Last line of a frame
    signal tst_vmax         : unsigned        (15 downto 0) := (others => '0');         -- Number of lines per frame - 1
    signal tst_size         : unsigned        (31 downto 0) := (others => '0');         -- Number of bytes per frame
    signal tst_frame_cnt    : unsigned        (31 downto 0) := (others => '0');         -- 32bit frame counter for Chunk metadata.
    signal tst_chunk_idx    : unsigned        ( 5 downto 0) := (others => '0');         -- Chunk data array read index
    signal tst_chunk_end    : unsigned        ( 5 downto 0) := (others => '0');         -- Chunk data array last index
    signal tst_chunk_inc    : std_logic                     := '0';                     -- Index increment enable
    signal tst_chunk_inc_r  : std_logic                     := '0';
    signal tst_chunk        : std_logic                     := '0';                     -- Frame buffer fb_frame for chunk data
    signal tst_chunk_data   : std_logic_vector(63 downto 0) := (others => '0');         -- Chunk data

    -- Data output control registers
    signal fb_out_en        : std_logic                     := '0';                     -- Acquisition enable

    -- Chunk control data array
    signal chunk_data_ar    : CHUNK_DATA_ARRAY(0 to 23);

begin

    -- Additional chunk control data array
    -- ... image chunk ID
    chunk_data_ar( 0) <= CHUNKID_IMG(31 downto 24);
    chunk_data_ar( 1) <= CHUNKID_IMG(23 downto 16);
    chunk_data_ar( 2) <= CHUNKID_IMG(15 downto  8);
    chunk_data_ar( 3) <= CHUNKID_IMG( 7 downto  0);
    -- ... image chunk size
    chunk_data_ar( 4) <= std_logic_vector(tst_size(31 downto 24));
    chunk_data_ar( 5) <= std_logic_vector(tst_size(23 downto 16));
    chunk_data_ar( 6) <= std_logic_vector(tst_size(15 downto  8));
    chunk_data_ar( 7) <= std_logic_vector(tst_size( 7 downto  0));
    -- ... frame counter data
    chunk_data_ar( 8) <= std_logic_vector(tst_frame_cnt(31 downto 24));
    chunk_data_ar( 9) <= std_logic_vector(tst_frame_cnt(23 downto 16));
    chunk_data_ar(10) <= std_logic_vector(tst_frame_cnt(15 downto  8));
    chunk_data_ar(11) <= std_logic_vector(tst_frame_cnt( 7 downto  0));
    -- ... frame counter chunk ID
    chunk_data_ar(12) <= CHUNKID_FC(31 downto 24);
    chunk_data_ar(13) <= CHUNKID_FC(23 downto 16);
    chunk_data_ar(14) <= CHUNKID_FC(15 downto  8);
    chunk_data_ar(15) <= CHUNKID_FC( 7 downto  0);
    -- ... frame counter chunk size
    chunk_data_ar(16) <= X"00";
    chunk_data_ar(17) <= X"00";
    chunk_data_ar(18) <= X"00";
    chunk_data_ar(19) <= X"04";
    -- ... pad to multiples of 8 byte (needed for TPG_OUT_MODE == 1)
    chunk_data_ar(20) <= X"00";
    chunk_data_ar(21) <= X"00";
    chunk_data_ar(22) <= X"00";
    chunk_data_ar(23) <= X"00";


    -- System to video clock domains boundary crossing
    SYS2AXIS_CLK_PROC: process (fb_clk) is
        variable sys_grab_en_x      : std_logic                     := '0';
        variable sys_img_width_x    : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_img_height_x   : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_offs_x_x       : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_offs_y_x       : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_pixfmt_x       : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_gap_x_x        : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_gap_y_x        : std_logic_vector(31 downto 0) := (others => '0');
        variable sys_chunk_ctrl_x   : std_logic_vector(31 downto 0) := (others => '0');
    begin
        if rising_edge(fb_clk) then

            -- Second FF stage
            ctrl_grab_en        <= sys_grab_en_x;
            ctrl_img_width      <= sys_img_width_x;
            ctrl_img_height     <= sys_img_height_x;
            ctrl_offs_x         <= sys_offs_x_x;
            ctrl_offs_y         <= sys_offs_y_x;
            ctrl_pixfmt         <= sys_pixfmt_x;
            ctrl_gap_x          <= sys_gap_x_x;
            ctrl_gap_y          <= sys_gap_y_x;
            ctrl_chunk_ctrl     <= sys_chunk_ctrl_x;

            -- First FF stage
            sys_grab_en_x       := tpg_control.grab_en;
            sys_img_width_x     := tpg_control.img_width;
            sys_img_height_x    := tpg_control.img_height;
            sys_offs_x_x        := tpg_control.offs_x;
            sys_offs_y_x        := tpg_control.offs_y;
            sys_pixfmt_x        := tpg_control.pixfmt;
            sys_gap_x_x         := tpg_control.gap_x;
            sys_gap_y_x         := tpg_control.gap_y;
            sys_chunk_ctrl_x    := tpg_control.chunk_ctrl;
        end if;
    end process SYS2AXIS_CLK_PROC;


    -- Image size counter, needed for image chunk
    BYTE_CNT_PROC: process (fb_clk) is
    variable incr : unsigned(3 downto 0);
    begin
        if rising_edge(fb_clk) then
            if tst_frame = '0' and tst_chunk_inc = '0' then
                tst_size <= (others => '0');
            elsif tst_line = '1' and tst_frame = '1' then
                incr := (unsigned('0' & tst_px_width) + 1);                             -- Increment counter depending fb data width
                tst_size <= tst_size + incr;
            end if;
        end if;
    end process BYTE_CNT_PROC;

    -- Frame counter, used for frame counter chunk
    FRAME_CNT_PROC: process (fb_clk) is
    begin
        if rising_edge(fb_clk) then
            tst_frame_r <= tst_frame;

            if fb_rst = '1' then
                tst_frame_cnt <= (others => '0');
            elsif tst_frame = '0' and tst_frame_r = '1' then
                tst_frame_cnt <= tst_frame_cnt + 1;                                     -- Increment frame counter at frame end
            end if;
        end if;
    end process FRAME_CNT_PROC;


    -- Generator
    TEST_GEN_PROC: process (fb_clk) is
    begin
        if rising_edge(fb_clk) then
            if fb_rst = '1' then
                tst_px_width  <= "000";
                tst_data      <= (others => '0');
                tst_frame     <= '0';
                tst_line      <= '0';
                tst_hcnt      <= (others => '0');
                tst_vcnt      <= (others => '0');
                tst_shift     <= (others => '0');
                tst_vmax      <= (others => '0');
                tst_hmax      <= (others => '0');
                tst_hend      <= (others => '0');
                tst_chunk_inc <= '0';
                tst_chunk     <= '0';
            else

                -- Horizontal parameters
                if TPG_OUT_MODE = 0 then
                    tst_hstart  <= unsigned(ctrl_offs_x(15 downto 0));
                    tst_hend    <= unsigned(ctrl_img_width (15 downto 0)) + tst_hstart;
                    tst_hmax    <= unsigned(ctrl_gap_x(15 downto 0)) + tst_hend;
                else
                    case ctrl_pixfmt is
                        -- 8 Pixel per clock cycle -> boundaries / 8
                        when PIX_MONO8  =>  tst_hstart  <= shift_right(unsigned(ctrl_offs_x   (15 downto 0)), 3);
                                            tst_hend    <= shift_right(unsigned(ctrl_img_width(15 downto 0)), 3) + tst_hstart;
                                            tst_hmax    <= shift_right(unsigned(ctrl_gap_x    (15 downto 0)), 3) + tst_hend;
                        -- 4 Pixel per clock cycle -> boundaries / 4
                        when PIX_MONO16 =>  tst_hstart  <= shift_right(unsigned(ctrl_offs_x   (15 downto 0)), 2);
                                            tst_hend    <= shift_right(unsigned(ctrl_img_width(15 downto 0)), 2) + tst_hstart;
                                            tst_hmax    <= shift_right(unsigned(ctrl_gap_x    (15 downto 0)), 2) + tst_hend;
                        -- 2 Pixel per clock cycle -> boundaries / 2
                        when PIX_RGB8   =>  tst_hstart  <= shift_right(unsigned(ctrl_offs_x   (15 downto 0)), 1);
                                            tst_hend    <= shift_right(unsigned(ctrl_img_width(15 downto 0)), 1) + tst_hstart;
                                            tst_hmax    <= shift_right(unsigned(ctrl_gap_x    (15 downto 0)), 1) + tst_hend;
                        -- Unknown formats
                        when others     =>  tst_hstart  <= unsigned(ctrl_offs_x(15 downto 0));
                                            tst_hend    <= unsigned(ctrl_img_width (15 downto 0)) + tst_hstart;
                                            tst_hmax    <= unsigned(ctrl_gap_x(15 downto 0)) + tst_hend;
                    end case;
                end if;

                -- Vertical parameters
                tst_vstart <= unsigned(ctrl_offs_y(15 downto 0));
                tst_vend   <= unsigned(ctrl_img_height(15 downto 0)) + tst_vstart;
                tst_vmax   <= unsigned(ctrl_gap_y(15 downto 0)) + tst_vend;

                -- Column and row counters
                if tst_hcnt /= tst_hmax then
                    tst_hcnt <= tst_hcnt + 1;
                else
                    tst_hcnt <= (others => '0');
                    if tst_vcnt /= tst_vmax then
                        tst_vcnt <= tst_vcnt + 1;
                    else
                        tst_vcnt  <= (others => '0');
                        tst_shift <= tst_shift - 1;
                    end if;
                end if;

                -- Line enable
                if tst_hcnt = tst_hstart then   tst_line <= '1';    end if;
                if tst_hcnt = tst_hend   then   tst_line <= '0';    end if;

                -- Frame enable and chunk enable
                if tst_vcnt = tst_vstart and tst_frame = '0' then
                    tst_frame <= '1';
                end if;
                if tst_vcnt = tst_vend  then
                    tst_frame <= '0';
                    if ctrl_chunk_ctrl(31) = '1' then                                   -- Chunk mode active
                        tst_chunk <= '1';
                        if tst_chunk_idx = 0 then
                            tst_chunk_inc <= '1';                                       -- Activate readout of chunk data array "chunk_data_ar"
                        end if;
                    else
                        tst_chunk <= '0';                                               -- Chunk mode disable
                    end if;
                end if;

                if tst_vcnt = tst_vend + 1  then
                    tst_chunk <= '0';                                                   -- Deactivate chunk write valid to framebuffer after one line period, may need adoption
                end if;

                if (tst_chunk_idx = 19 and tst_px_width = "000") or                     -- Read until index 19 for  8b pixeltype
                   (tst_chunk_idx = 18 and tst_px_width = "001") or                     -- Read until index 18 for 16b pixeltype
                   (tst_chunk_idx = 18 and tst_px_width = "010") or                     -- Read until index 18 for 24b pixeltype
                   (tst_chunk_idx = 16 and tst_px_width = "011") or                     -- Read until index 16 for 32b pixeltype
                   (tst_chunk_idx = 18 and tst_px_width = "101") or                     -- Read until index 16 for 48b pixeltype
                   (tst_chunk_idx = 16 and tst_px_width = "111")                        -- Read until index 16 for 64b pixeltype
                then
                    tst_chunk_inc <= '0';                                               -- Deactivate readout of chunk data array "chunk_data_ar"
                end if;

                if tst_chunk_inc = '1' or (tst_chunk_inc = '0' and tst_vcnt = tst_vend) then
                    if tst_chunk_idx < 20 then
                        tst_chunk_idx <= tst_chunk_idx + unsigned(tst_px_width) + 1;    -- Increment chunk data array readout index, dependent on pixelsize
                    end if;
                elsif tst_frame = '1' then
                    tst_chunk_idx <= (others => '0');                                   -- If image active, reset chunk data array readout index
                end if;

                tst_chunk_inc_r <= tst_chunk_inc;

                -- Chunk data
                case tst_px_width is
                    when "000"      => tst_chunk_data   <= x"00000000000000" &
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 0);  -- Byte 0
                    when "001"      => tst_chunk_data   <= x"000000000000" &
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 0) & -- Byte 0
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 1);  -- Byte 1
                    when "010"      => tst_chunk_data   <= x"0000000000" &
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 0) & -- Byte 0
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 1) & -- Byte 1
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 2);  -- Byte 2
                    when "101"      => tst_chunk_data   <= x"0000" &
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 0) & -- Byte 0
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 1) & -- Byte 1
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 2) & -- Byte 2
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 3) & -- Byte 3
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 4) & -- Byte 4
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 5);  -- Byte 5
                    when "111"      => tst_chunk_data   <= chunk_data_ar(to_integer(tst_chunk_idx) + 0) & -- Byte 0
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 1) & -- Byte 1
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 2) & -- Byte 2
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 3) & -- Byte 3
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 4) & -- Byte 4
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 5) & -- Byte 5
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 6) & -- Byte 6
                                                           chunk_data_ar(to_integer(tst_chunk_idx) + 7);  -- Byte 7
                    when others     => tst_chunk_data   <= (others => '0');
                end case;

                -- Pixel data
                if TPG_OUT_MODE = 0 then
                    -- normal output mode, one pixel per cycle
                    case ctrl_pixfmt is
                        when PIX_MONO8  =>  tst_data        <= x"00000000000000" & std_logic_vector(tst_hcnt(7 downto 0) + tst_shift);
                                            tst_px_width    <= "000";
                        when PIX_MONO16 =>  tst_data        <= x"000000000000" & not(std_logic_vector(tst_hcnt(7 downto 0) + tst_shift)) & (std_logic_vector(tst_hcnt(7 downto 0) + tst_shift));
                                            tst_px_width    <= "001";
                        when PIX_RGB8   =>  tst_data        <= x"0000000000" & (std_logic_vector(tst_hcnt(7 downto 0) + tst_shift)) & (std_logic_vector(tst_hcnt(7 downto 0) + tst_shift)) & (std_logic_vector(tst_hcnt(7 downto 0) + tst_shift));
                                            tst_px_width    <= "010";
                        when others     =>  tst_data        <= (others => '0');
                                            tst_px_width    <= "000";
                    end case;
                else
                    -- several pixel per cycle output
                    case ctrl_pixfmt is
                        when PIX_MONO8  =>  tst_data        <= std_logic_vector((tst_hcnt(4 downto 0) & "000") + tst_shift) & -- Pixel 0
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "001") + tst_shift) & -- Pixel 1
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "010") + tst_shift) & -- Pixel 2
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "011") + tst_shift) & -- Pixel 3
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "100") + tst_shift) & -- Pixel 4
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "101") + tst_shift) & -- Pixel 5
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "110") + tst_shift) & -- Pixel 6
                                                               std_logic_vector((tst_hcnt(4 downto 0) & "111") + tst_shift);  -- Pixel 7
                                            tst_px_width    <= "111";
                        when PIX_MONO16 =>  tst_data        <= not(std_logic_vector((tst_hcnt(5 downto 0) & "00") + tst_shift)) & std_logic_vector((tst_hcnt(5 downto 0) & "00") + tst_shift) & -- Pixel 0
                                                               not(std_logic_vector((tst_hcnt(5 downto 0) & "01") + tst_shift)) & std_logic_vector((tst_hcnt(5 downto 0) & "01") + tst_shift) & -- Pixel 1
                                                               not(std_logic_vector((tst_hcnt(5 downto 0) & "10") + tst_shift)) & std_logic_vector((tst_hcnt(5 downto 0) & "10") + tst_shift) & -- Pixel 2
                                                               not(std_logic_vector((tst_hcnt(5 downto 0) & "11") + tst_shift)) & std_logic_vector((tst_hcnt(5 downto 0) & "11") + tst_shift);  -- Pixel 3
                                            tst_px_width    <= "111";
                        when PIX_RGB8   =>  tst_data        <= x"0000" &
                                                               std_logic_vector((tst_hcnt(6 downto 0) & "0") + tst_shift) & std_logic_vector((tst_hcnt(6 downto 0) & "0") + tst_shift) & std_logic_vector((tst_hcnt(6 downto 0) & "0") + tst_shift) & -- Pixel 0
                                                               std_logic_vector((tst_hcnt(6 downto 0) & "1") + tst_shift) & std_logic_vector((tst_hcnt(6 downto 0) & "1") + tst_shift) & std_logic_vector((tst_hcnt(6 downto 0) & "1") + tst_shift);  -- Pixel 1
                                            tst_px_width    <= "101";
                        when others     => null;
                    end case;
                end if;
            end if;
        end if;
    end process TEST_GEN_PROC;


    -- Test pattern data
    DATA_OUT_PROC: process (fb_clk) is
    begin
        if rising_edge(fb_clk) then
            if fb_rst = '1' then
                fb_out_en <= '0';
                fb_data   <= (others => '0');
                fb_frame  <= '0';
                fb_dv     <= '0';
            else
                -- Output enable
                if tst_frame = '0' and tst_chunk = '0' then
                    fb_out_en <= ctrl_grab_en;
                end if;

                -- Video data output
                if fb_out_en = '1' then
                    if tst_chunk_inc = '1' or tst_chunk_inc_r = '1' then
                        fb_data <= tst_chunk_data;                                                  -- Write chunk data
                    else
                        fb_data <= tst_data;                                                        -- Write pixel data
                    end if;
                    fb_frame <= tst_frame or tst_chunk;                                             -- Block consists of pixel data and chunk data
                    fb_dv    <= (tst_line and not tst_chunk) or tst_chunk_inc or tst_chunk_inc_r;   -- Write line data or chunk data
                else
                    fb_data  <= (others => '0');
                    fb_frame <= '0';
                    fb_dv    <= '0';
                end if;
            end if;
        end if;
    end process DATA_OUT_PROC;


    -- simple signal assignments
    fb_width <= "0000" & tst_px_width;

end architecture rtl;
