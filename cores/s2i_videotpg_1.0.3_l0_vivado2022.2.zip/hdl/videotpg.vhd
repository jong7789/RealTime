-- ************************************************************************** --
-- *  videotpg                                                              * --
-- *------------------------------------------------------------------------* --
-- *  Module :  VIDEOTPG-RTL                                                * --
-- *    File :  videotpg.vhd                                                * --
-- *    Date :  2021-07-26                                                  * --
-- *     Rev :  0.1                                                         * --
-- *  Author :  SS                                                          * --
-- *------------------------------------------------------------------------* --
-- *  top level module                                                      * --
-- *------------------------------------------------------------------------* --
-- *  0.1  |  2021-07-26  |  SS  |  Initial release                         * --
-- ************************************************************************** --


library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     work.tpg_lib.all;


--------------------------------------------------------------------------------
--  TPG-TOP entity
--------------------------------------------------------------------------------

entity videotpg is

    generic(TPG_OUT_MODE    : natural range 0 to 1  := 0;                            -- '0': 1 Pixel per clock, '1': several Pixel per clock
            AXI_ADDR_WIDTH  : natural               := 16);                          -- Width of the AXI4-Lite slave address

    port   (-- AXI4-Lite CPU interface
            s_axi_aclk      : in    std_logic;                                       -- AXI4-Lite clock
            s_axi_aresetn   : in    std_logic;                                       -- AXI4-Lite active-low reset
            s_axi_awaddr    : in    std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);   -- Write address channel
            s_axi_awprot    : in    std_logic_vector(                 2 downto 0);
            s_axi_awvalid   : in    std_logic;
            s_axi_awready   : out   std_logic;
            s_axi_wdata     : in    std_logic_vector(                31 downto 0);   -- Write data channel
            s_axi_wstrb     : in    std_logic_vector(                 3 downto 0);
            s_axi_wvalid    : in    std_logic;
            s_axi_wready    : out   std_logic;
            s_axi_bresp     : out   std_logic_vector(                 1 downto 0);   -- Write response channel
            s_axi_bvalid    : out   std_logic;
            s_axi_bready    : in    std_logic;
            s_axi_araddr    : in    std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);   -- Read address channel
            s_axi_arprot    : in    std_logic_vector(                 2 downto 0);
            s_axi_arvalid   : in    std_logic;
            s_axi_arready   : out   std_logic;
            s_axi_rdata     : out   std_logic_vector(                31 downto 0);   -- Read data channel
            s_axi_rresp     : out   std_logic_vector(                 1 downto 0);
            s_axi_rvalid    : out   std_logic;
            s_axi_rready    : in    std_logic;
            -- DIP switch
            gpio_in         : in    std_logic_vector(                31 downto 0);
            gpio_out        : out   std_logic_vector(                31 downto 0);
            -- GEV Stream Channel interface
            gev_scc         : in    std_logic;                                       -- Stream channel closed
            -- Framebuffer interface               
            fb_clk          : in    std_logic;                                       -- Interface clock
            fb_rst          : in    std_logic;                                       -- Synchronous reset
            fb_frame        : out   std_logic;                                       -- Frame valid
            fb_dv           : out   std_logic;                                       -- Data valid
            fb_data         : out   std_logic_vector(                63 downto 0);   -- Pixel data
            fb_width        : out   std_logic_vector(                 6 downto 0));  -- Memory interface data width

begin

    -- Check valid AXI4-Lite address width
    assert AXI_ADDR_WIDTH >= 16
        report "VIDEO-TPG: Unsupported AXI4-Lite slave address width (must be at least 16)!"
        severity failure;

end entity videotpg;


architecture top of videotpg is

    -- Control signals to configure test pattern generator.
    -- Axislave -> test pattern generator
    signal tpg_control : TPG_CONTROL_T;

    -- Status signals to read back eventual status from test pattern generator.
    -- Test pattern generator -> axislave
    signal tpg_status : TPG_STATUS_T;

begin

    -- CPU interface
    AXI_SLAVE_INST: entity work.axislave
        generic map(
                 AXI_ADDR_WIDTH => AXI_ADDR_WIDTH,
                 TPG_OUT_MODE   => TPG_OUT_MODE)
        port map(-- AXI4-Lite interface
                 axi_aclk       => s_axi_aclk,
                 axi_aresetn    => s_axi_aresetn,
                 axi_awaddr     => s_axi_awaddr,
                 axi_awvalid    => s_axi_awvalid,
                 axi_awready    => s_axi_awready,
                 axi_wdata      => s_axi_wdata,
                 axi_wstrb      => s_axi_wstrb,
                 axi_wvalid     => s_axi_wvalid,
                 axi_wready     => s_axi_wready,
                 axi_bresp      => s_axi_bresp,
                 axi_bvalid     => s_axi_bvalid,
                 axi_bready     => s_axi_bready,
                 axi_araddr     => s_axi_araddr,
                 axi_arvalid    => s_axi_arvalid,
                 axi_arready    => s_axi_arready,
                 axi_rdata      => s_axi_rdata,
                 axi_rresp      => s_axi_rresp,
                 axi_rvalid     => s_axi_rvalid,
                 axi_rready     => s_axi_rready,
                 -- axislave <-> tpg
                 tpg_control    => tpg_control,
                 tpg_status     => tpg_status,
                 gpio_in        => gpio_in,
                 gpio_out       => gpio_out);

    TPG_INST: entity work.tpg
        generic map(
                 TPG_OUT_MODE => TPG_OUT_MODE)
        port map(sys_rst        => s_axi_aresetn,
                 -- control and status interface
                 tpg_control    => tpg_control,
                 tpg_status     => tpg_status,
                 -- GEV Stream Channel interface
                 gev_scc        => gev_scc,
                 -- Framebuffer interface
                 fb_clk         => fb_clk,
                 fb_rst         => fb_rst,
                 fb_frame       => fb_frame,
                 fb_dv          => fb_dv,
                 fb_data        => fb_data,
                 fb_width       => fb_width);

end architecture top;
