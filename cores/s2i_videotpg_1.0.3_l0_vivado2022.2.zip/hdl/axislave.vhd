-- ************************************************************************** --
-- *  videotpg                                                              * --
-- *------------------------------------------------------------------------* --
-- *  Module :  AXISLAVE-RTL                                                * --
-- *    File :  axislave.vhd                                                * --
-- *    Date :  2021-07-26                                                  * --
-- *     Rev :  0.1                                                         * --
-- *  Author :  SS                                                          * --
-- *------------------------------------------------------------------------* --
-- *  axislave for the videotpg core.                                       * --
-- *------------------------------------------------------------------------* --
-- *  0.1  |  2021-07-26  |  SS  |  Initial release                         * --
-- ************************************************************************** --


library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     work.tpg_lib.all;


--------------------------------------------------------------------------------
--  AXISLAVE-TOP entity
--------------------------------------------------------------------------------

entity axislave is

    generic(AXI_ADDR_WIDTH      : natural;                                              -- AXI4-Lite slave address width
            TPG_OUT_MODE        : natural);                                             -- '0': 1 Pixel per clock, '1': several Pixel per clock
    port   (-- AXI4-Lite slave interface
            axi_aclk            : in    std_logic;                                      -- Clock and reset
            axi_aresetn         : in    std_logic;
            axi_awaddr          : in    std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);  -- Write address channel
            axi_awvalid         : in    std_logic;
            axi_awready         : out   std_logic;
            axi_wdata           : in    std_logic_vector(                31 downto 0);  -- Write data channel
            axi_wstrb           : in    std_logic_vector(                 3 downto 0);
            axi_wvalid          : in    std_logic;
            axi_wready          : out   std_logic;
            axi_bresp           : out   std_logic_vector(                 1 downto 0);  -- Write response channel
            axi_bvalid          : out   std_logic;
            axi_bready          : in    std_logic;
            axi_araddr          : in    std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);  -- Read address channel
            axi_arvalid         : in    std_logic;
            axi_arready         : out   std_logic;
            axi_rdata           : out   std_logic_vector(                31 downto 0);  -- Read data channel
            axi_rresp           : out   std_logic_vector(                 1 downto 0);
            axi_rvalid          : out   std_logic;
            axi_rready          : in    std_logic;
            -- Axislave <-> tpg
            tpg_control         : out   TPG_CONTROL_T;                                  -- tpg control interface
            tpg_status          : in    TPG_STATUS_T;                                   -- tpg status interface
            gpio_in             : in    std_logic_vector(                31 downto 0);  -- GPIO
            gpio_out            : out   std_logic_vector(                31 downto 0)); -- GPIO

end entity axislave;


--------------------------------------------------------------------------------
--  AXISLAVE-TOP architecture
--------------------------------------------------------------------------------

architecture rtl of axislave is

    -- Internal AXI4-Lite registers
    signal axi_awaddr_r         : std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);
    signal axi_awready_r        : std_logic;
    signal axi_wready_r         : std_logic;
    signal axi_bvalid_r         : std_logic;
    signal axi_araddr_r         : std_logic_vector(AXI_ADDR_WIDTH - 1 downto 0);
    signal axi_arready_r        : std_logic;
    signal axi_rdata_r          : std_logic_vector(31 downto 0);
    signal axi_rvalid_r         : std_logic;

    -- TPG control and status registers
    signal reg_grab_en          : std_logic                     := '0';
    signal reg_img_width        : std_logic_vector(31 downto 0) := DEF_IMG_WIDTH;
    signal reg_img_height       : std_logic_vector(31 downto 0) := DEF_IMG_HEIGHT;
    signal reg_offs_x           : std_logic_vector(31 downto 0) := DEF_OFFS_X;
    signal reg_offs_y           : std_logic_vector(31 downto 0) := DEF_OFFS_Y;
    signal reg_pixfmt           : std_logic_vector(31 downto 0) := DEF_PIXFMT;
    signal reg_gap_x            : std_logic_vector(31 downto 0) := DEF_GAP_X;
    signal reg_gap_y            : std_logic_vector(31 downto 0) := DEF_GAP_Y;
    signal reg_gpio_in          : std_logic_vector(31 downto 0) := DEF_GPIO_IN;
    signal reg_gpio_out         : std_logic_vector(31 downto 0) := DEF_GPIO_OUT;
    signal reg_chunk_ctrl       : std_logic_vector(31 downto 0) := DEF_CHUNK_CTRL;

begin

    -- Write access ------------------------------------------------------------

    -- Write address/data ready and address register
    WRITE_READY_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_awready_r <= '0';
                axi_wready_r  <= '0';
                axi_awaddr_r  <= (others => '0');
            else
                -- Write channels ready
                axi_awready_r <= axi_awvalid and axi_wvalid and (not axi_bvalid_r) and (not axi_awready_r);
                axi_wready_r  <= axi_awvalid and axi_wvalid and (not axi_bvalid_r) and (not axi_wready_r);
                -- Latch write address
                if axi_awvalid = '1' and axi_wvalid = '1' and axi_awready_r = '0' then
                    axi_awaddr_r <= axi_awaddr;
                end if;
            end if;
        end if;
    end process WRITE_READY_PROC;

    -- Write response
    WRITE_RESP_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_bvalid_r <= '0';
            else
                if axi_awready_r = '1' and axi_awvalid = '1' and axi_wready_r = '1' and axi_wvalid = '1' and axi_bvalid_r = '0' then
                    axi_bvalid_r <= '1';
                elsif axi_bready = '1' and axi_bvalid_r = '1' then
                    axi_bvalid_r <= '0';
                end if;
            end if;
        end if;
    end process WRITE_RESP_PROC;

    -- Register write
    WRITE_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                -- Common control
                reg_grab_en    <= '0';
                reg_img_width  <= DEF_IMG_WIDTH;
                reg_img_height <= DEF_IMG_HEIGHT;
                reg_offs_x     <= DEF_OFFS_X;
                reg_offs_y     <= DEF_OFFS_Y;
                reg_pixfmt     <= DEF_PIXFMT;
                reg_gap_x      <= DEF_GAP_X;
                reg_gap_y      <= DEF_GAP_Y;
                reg_chunk_ctrl <= DEF_CHUNK_CTRL;
            else
                -- Write access
                if axi_wready_r = '1' and axi_wvalid = '1' and axi_awready_r = '1' and axi_awvalid = '1' then
                    case axi_awaddr_r(ADDR_WIDTH - 1 downto 2) is
                        when ADDR_GCSR       (ADDR_WIDTH - 1 downto 2)  =>   reg_grab_en      <= axi_wdata(0);
                        when ADDR_IMG_WIDTH  (ADDR_WIDTH - 1 downto 2)  =>   reg_img_width    <= assign_be(reg_img_width,  axi_wdata, axi_wstrb);
                        when ADDR_IMG_HEIGHT (ADDR_WIDTH - 1 downto 2)  =>   reg_img_height   <= assign_be(reg_img_height, axi_wdata, axi_wstrb);
                        when ADDR_OFFS_X     (ADDR_WIDTH - 1 downto 2)  =>   reg_offs_x       <= assign_be(reg_offs_x,     axi_wdata, axi_wstrb);
                        when ADDR_OFFS_Y     (ADDR_WIDTH - 1 downto 2)  =>   reg_offs_y       <= assign_be(reg_offs_y,     axi_wdata, axi_wstrb);
                        when ADDR_PIXFMT     (ADDR_WIDTH - 1 downto 2)  =>   reg_pixfmt       <= assign_be(reg_pixfmt,     axi_wdata, axi_wstrb);
                        when ADDR_GAP_X      (ADDR_WIDTH - 1 downto 2)  =>   reg_gap_x        <= assign_be(reg_gap_x,      axi_wdata, axi_wstrb);
                        when ADDR_GAP_Y      (ADDR_WIDTH - 1 downto 2)  =>   reg_gap_y        <= assign_be(reg_gap_y,      axi_wdata, axi_wstrb);
                        when ADDR_GPIO_OUT   (ADDR_WIDTH - 1 downto 2)  =>   reg_gpio_out     <= assign_be(reg_gpio_out,   axi_wdata, axi_wstrb);
                        when ADDR_CHUNK_CTRL (ADDR_WIDTH - 1 downto 2)  =>   reg_chunk_ctrl   <= assign_be(reg_chunk_ctrl, axi_wdata, axi_wstrb);
                        when others                                     =>   null;
                    end case;
                end if;
            end if;
        end if;
    end process WRITE_PROC;


    -- Read access -------------------------------------------------------------

    -- Read address ready and address register
    READ_READY_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_arready_r <= '0';
                axi_araddr_r  <= (others => '0');
            else
                -- Read address ready
                axi_arready_r <= axi_arvalid;
                -- Latch read address
                if axi_arready_r = '0' and axi_arvalid = '1' then
                    axi_araddr_r  <= axi_araddr;
                end if;
            end if;
        end if;
    end process READ_READY_PROC;

    -- Read data valid
    READ_VALID_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_rvalid_r <= '0';
            else
                if axi_arready_r = '1' and axi_arvalid = '1' and axi_rvalid_r = '0' then
                    axi_rvalid_r <= '1';
                elsif axi_rvalid_r = '1' and axi_rready = '1' then
                    axi_rvalid_r <= '0';
                end if;
            end if;
        end if;
    end process READ_VALID_PROC;

    -- Register read
    READ_PROC: process (axi_aclk) is
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                axi_rdata_r <= (others => '0');
            else
                reg_gpio_in <= gpio_in;
                if axi_arready_r = '1' and axi_arvalid = '1' and axi_rvalid_r = '0' then
                    case axi_araddr_r(ADDR_WIDTH - 1 downto 2) is
                        when ADDR_GCSR        (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= x"0000000" & "000" & reg_grab_en;
                        when ADDR_IMG_WIDTH   (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_img_width;
                        when ADDR_IMG_HEIGHT  (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_img_height;
                        when ADDR_OFFS_X      (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_offs_x;
                        when ADDR_OFFS_Y      (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_offs_y;
                        when ADDR_PIXFMT      (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_pixfmt;
                        when ADDR_GAP_X       (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_gap_x;
                        when ADDR_GAP_Y       (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_gap_y;
                        when ADDR_GPIO_OUT    (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_gpio_out;
                        when ADDR_GPIO_IN     (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_gpio_in;
                        when ADDR_CHUNK_CTRL  (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= reg_chunk_ctrl;
                        when ADDR_CHUNKID_IMG (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= CHUNKID_IMG;
                        when ADDR_CHUNKID_FC  (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= CHUNKID_FC;
                        when ADDR_TPG_MODE    (ADDR_WIDTH - 1 downto 2) =>  axi_rdata_r <= std_logic_vector(to_unsigned(TPG_OUT_MODE, 32));
                        when others                                     =>  axi_rdata_r <= (others => '0');
                    end case;
                end if;
            end if;
        end if;
    end process READ_PROC;


    -- Simple signal assignments ------------------------------------------------------

    -- AXI output ports
    axi_awready <= axi_awready_r and axi_awvalid;
    axi_wready  <= axi_wready_r  and axi_wvalid;
    axi_bresp   <= "00";
    axi_bvalid  <= axi_bvalid_r;
    axi_arready <= axi_arready_r and axi_arvalid;
    axi_rdata   <= axi_rdata_r;
    axi_rresp   <= "00";
    axi_rvalid  <= axi_rvalid_r;

    -- control outputs
    tpg_control.grab_en     <= reg_grab_en;
    tpg_control.img_width   <= reg_img_width;
    tpg_control.img_height  <= reg_img_height;
    tpg_control.offs_x      <= reg_offs_x;
    tpg_control.offs_y      <= reg_offs_y;
    tpg_control.pixfmt      <= reg_pixfmt;
    tpg_control.gap_x       <= reg_gap_x;
    tpg_control.gap_y       <= reg_gap_y;
    tpg_control.chunk_ctrl  <= reg_chunk_ctrl;
    
    gpio_out                <= reg_gpio_out;

end rtl;