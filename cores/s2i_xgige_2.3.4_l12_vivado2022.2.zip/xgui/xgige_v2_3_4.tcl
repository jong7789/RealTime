# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  #Adding Group
  set Buffers [ipgui::add_group $IPINST -name "Buffers" -parent ${Page_0}]
  ipgui::add_param $IPINST -name "TXBUF_AWIDTH" -parent ${Buffers} -widget comboBox
  ipgui::add_param $IPINST -name "RXBUF_CPU_AWIDTH" -parent ${Buffers} -widget comboBox

  #Adding Group
  set Action_Commands [ipgui::add_group $IPINST -name "Action Commands" -parent ${Page_0}]
  ipgui::add_param $IPINST -name "ACTION_RX_EN" -parent ${Action_Commands}
  ipgui::add_param $IPINST -name "ACTION_TX_EN" -parent ${Action_Commands}
  ipgui::add_param $IPINST -name "ACTION_SIGNALS" -parent ${Action_Commands} -widget comboBox



}

proc update_PARAM_VALUE.ACTION_RX_EN { PARAM_VALUE.ACTION_RX_EN } {
	# Procedure called to update ACTION_RX_EN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ACTION_RX_EN { PARAM_VALUE.ACTION_RX_EN } {
	# Procedure called to validate ACTION_RX_EN
	return true
}

proc update_PARAM_VALUE.ACTION_SIGNALS { PARAM_VALUE.ACTION_SIGNALS } {
	# Procedure called to update ACTION_SIGNALS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ACTION_SIGNALS { PARAM_VALUE.ACTION_SIGNALS } {
	# Procedure called to validate ACTION_SIGNALS
	return true
}

proc update_PARAM_VALUE.ACTION_TX_EN { PARAM_VALUE.ACTION_TX_EN } {
	# Procedure called to update ACTION_TX_EN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ACTION_TX_EN { PARAM_VALUE.ACTION_TX_EN } {
	# Procedure called to validate ACTION_TX_EN
	return true
}

proc update_PARAM_VALUE.RXBUF_CPU_AWIDTH { PARAM_VALUE.RXBUF_CPU_AWIDTH } {
	# Procedure called to update RXBUF_CPU_AWIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.RXBUF_CPU_AWIDTH { PARAM_VALUE.RXBUF_CPU_AWIDTH } {
	# Procedure called to validate RXBUF_CPU_AWIDTH
	return true
}

proc update_PARAM_VALUE.TXBUF_AWIDTH { PARAM_VALUE.TXBUF_AWIDTH } {
	# Procedure called to update TXBUF_AWIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TXBUF_AWIDTH { PARAM_VALUE.TXBUF_AWIDTH } {
	# Procedure called to validate TXBUF_AWIDTH
	return true
}


proc update_MODELPARAM_VALUE.TXBUF_AWIDTH { MODELPARAM_VALUE.TXBUF_AWIDTH PARAM_VALUE.TXBUF_AWIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TXBUF_AWIDTH}] ${MODELPARAM_VALUE.TXBUF_AWIDTH}
}

proc update_MODELPARAM_VALUE.RXBUF_CPU_AWIDTH { MODELPARAM_VALUE.RXBUF_CPU_AWIDTH PARAM_VALUE.RXBUF_CPU_AWIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.RXBUF_CPU_AWIDTH}] ${MODELPARAM_VALUE.RXBUF_CPU_AWIDTH}
}

proc update_MODELPARAM_VALUE.ACTION_RX_EN { MODELPARAM_VALUE.ACTION_RX_EN PARAM_VALUE.ACTION_RX_EN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ACTION_RX_EN}] ${MODELPARAM_VALUE.ACTION_RX_EN}
}

proc update_MODELPARAM_VALUE.ACTION_TX_EN { MODELPARAM_VALUE.ACTION_TX_EN PARAM_VALUE.ACTION_TX_EN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ACTION_TX_EN}] ${MODELPARAM_VALUE.ACTION_TX_EN}
}

proc update_MODELPARAM_VALUE.ACTION_SIGNALS { MODELPARAM_VALUE.ACTION_SIGNALS PARAM_VALUE.ACTION_SIGNALS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ACTION_SIGNALS}] ${MODELPARAM_VALUE.ACTION_SIGNALS}
}

