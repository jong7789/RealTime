/******************************************************************************/
/*  GigE Vision Bootloader                                                    */
/*----------------------------------------------------------------------------*/
/*    File :  flash.c                                                         */
/*    Date :  2014-07-28                                                      */
/*     Rev :  0.5                                                             */
/*  Author :  JP                                                              */
/*----------------------------------------------------------------------------*/
/*  SPI flash memory control routines                                         */
/*----------------------------------------------------------------------------*/
/*  0.1  |  2008-03-07  |  JP  |  Initial release                             */
/*  0.2  |  2009-05-13  |  JP  |  Added status register read/write functions  */
/*  0.3  |  2012-07-13  |  JP  |  Flash write and read follow CPU endianness  */
/*  0.4  |  2013-12-09  |  MAS |  Generic constants for sector and page sizes */
/*  0.5  |  2014-07-28  |  JP  |  Block index extended to 16 bits, support    */
/*       |              |      |  for SPI 4B address mode                     */
/******************************************************************************/

#include "boot.h"


// ---- Read status register ---------------------------------------------------
//
u8 flash_getstat()
{
    gige_spi_gcsr = 0x00000700;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    return (u8)(gige_spi_rbuf[0] >> 24);
}


// ---- Write status register --------------------------------------------------
//
void flash_setstat(u8 val)
{
    gige_spi_wbuf[0] = ((u32)val) << 24;
    gige_spi_gcsr    = 0x00000600;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    return;
}


// ---- Enter 4B address mode --------------------------------------------------
//
void flash_enter4b()
{
    gige_spi_gcsr = 0x00000800;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    return;
}


// ---- Exit 4B address mode ---------------------------------------------------
//
void flash_exit4b()
{
    gige_spi_gcsr = 0x00000900;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    return;
}


// ---- Read data parameters ---------------------------------------------------
//
void flash_getpar(u8 idx, u32 *len, u32 *sum)
{
    // Read the block length
    gige_spi_addr = ((u32)idx * 8) + (FLASH_PARAMETERS * SECTOR_SIZE);
    gige_spi_gcsr = 0x00000207;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    // Return values
    *len = gige_spi_rbuf[0];
    *sum = gige_spi_rbuf[1];

    return;
}


// ---- Write data parameters --------------------------------------------------
//
void flash_setpar(u8 idx, u32 len, u32 sum)
{
    int i;

    // Read old values
    gige_spi_addr = FLASH_PARAMETERS * SECTOR_SIZE;
    gige_spi_gcsr = 0x00000200 | ((PARTITIONS * 8) - 1);
    while (!(gige_spi_gcsr & 0x80000000)) {};

    // Prepare updated values
    for (i = 0; i < (PARTITIONS * 2); i++)
        gige_spi_wbuf[i] = gige_spi_rbuf[i];
    gige_spi_wbuf[ idx * 2     ] = len;
    gige_spi_wbuf[(idx * 2) + 1] = sum;

    // Erase the block
    gige_spi_gcsr = 0x00000500;
    while (!(gige_spi_gcsr & 0x80000000)) {};

    // Write the values
    gige_spi_gcsr = 0x00000100 | ((PARTITIONS * 8) - 1);
    while (!(gige_spi_gcsr & 0x80000000)) {};

    return;
}


// ---- Write data block into flash --------------------------------------------
//
void flash_write(u16 block, u32 *addr, u32 len)
{
    u32 burst, blen, i;

    // Erase block
    gige_spi_addr = (u32)block * SECTOR_SIZE;
#ifdef LITTLE_ENDIAN
    gige_spi_gcsr = 0x00010500;
#else
    gige_spi_gcsr = 0x00000500;
#endif
    while (!(gige_spi_gcsr & 0x80000000)) {};

    // Write block
    for (burst = 0; (burst * PAGE_SIZE) < len; burst++)
    {
        blen = minimum(len - (burst * PAGE_SIZE), PAGE_SIZE);
        for (i = 0; (i * 4) < blen; i++)
            gige_spi_wbuf[i] = *addr++;
        gige_spi_addr = ((u32)block * SECTOR_SIZE) + (burst * PAGE_SIZE);
#ifdef LITTLE_ENDIAN
        gige_spi_gcsr = 0x00010100 | ((blen - 1) & 0xFF);
#else
        gige_spi_gcsr = 0x00000100 | ((blen - 1) & 0xFF);
#endif
        while (!(gige_spi_gcsr & 0x80000000)) {};
    }

    return;
}


// ---- Read data block from flash ---------------------------------------------
//
u32 flash_read(u16 block, u32 **addr, u32 len)
{
    u32 burst, blen = 0, i = 0, bytes = 0;
    u32 sum = 0;

    // Read block
    for (burst = 0; (burst * PAGE_SIZE) < len; burst++)
    {
        blen = minimum(len - (burst * PAGE_SIZE), PAGE_SIZE);
        gige_spi_addr = ((u32)block * SECTOR_SIZE) + (burst * PAGE_SIZE);
#ifdef LITTLE_ENDIAN
        gige_spi_gcsr = 0x00010200 | ((blen - 1) & 0xFF);
#else
        gige_spi_gcsr = 0x00000200 | ((blen - 1) & 0xFF);
#endif
        while (!(gige_spi_gcsr & 0x80000000)) {};
        for (i = 0; (i * 4) < blen; i++)
        {
            *(*addr)++ = gige_spi_rbuf[i];
            for (bytes = 0; bytes < 4; bytes++)
                sum += (gige_spi_rbuf[i] >> (bytes * 8)) & 0xFF;
        }
    }

    // Correct the sum when last dword is not complete
    if (blen % 4)
        for (bytes = 0; bytes < (4 - (blen % 4)); bytes++)
            sum -= (gige_spi_rbuf[i - 1] >> (bytes * 8)) & 0xFF;

    return sum;
}


// ---- Calculate check sum of data block --------------------------------------
//
u32 flash_sum(u16 block, u32 len)
{
    u32 burst, blen = 0, i = 0, bytes = 0;
    u32 sum = 0;

    // Read block and calculate its checksum
    for (burst = 0; (burst * PAGE_SIZE) < len; burst++)
    {
        blen = minimum(len - (burst * PAGE_SIZE), PAGE_SIZE);
        gige_spi_addr = ((u32)block * SECTOR_SIZE) + (burst * PAGE_SIZE);
        gige_spi_gcsr = 0x00000200 | ((blen - 1) & 0xFF);
        while (!(gige_spi_gcsr & 0x80000000)) {};
        for (i = 0; (i * 4) < blen; i++)
            for (bytes = 0; bytes < 4; bytes++)
                sum += (gige_spi_rbuf[i] >> (bytes * 8)) & 0xFF;
    }

    // Correct the sum when last dword is not complete
    if (blen % 4)
        for (bytes = 0; bytes < (4 - (blen % 4)); bytes++)
            sum -= (gige_spi_rbuf[i - 1] >> (bytes * 8)) & 0xFF;

    return sum;
}
