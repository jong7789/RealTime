/******************************************************************************/
/*  GigE Vision Bootloader                                                    */
/*----------------------------------------------------------------------------*/
/*    File :  boot.c                                                          */
/*    Date :  2022-07-27                                                      */
/*     Rev :  1.25                                                            */
/*  Author :  JP                                                              */
/*----------------------------------------------------------------------------*/
/*  Main module of the bootloader                                             */
/*----------------------------------------------------------------------------*/
/*  0.1  |  2008-03-07  |  JP  |  Initial release                             */
/*  0.x  |  2008-03-07  |  JP  |  Various changes and updates                 */
/*  1.0  |  2008-??-??  |  JP  |  Boot from Xilinx platform FLASH supported   */
/*  1.1  |  2008-09-19  |  JP  |  Always tries to boot from platform flash    */
/*       |              |      |  and continues with SPI when it fails        */
/*  1.2  |  2008-10-14  |  JP  |  Changed boot order (1. SPI, 2. Xilinx)      */
/*  1.3  |  2009-02-03  |  JP  |  Extended the S/N output                     */
/*  1.4  |  2009-05-13  |  JP  |  Support for flash write protection, Xilinx  */
/*       |              |      |  platform flash support is conditional       */
/*  1.5  |  2010-04-14  |  JP  |  Better MPMC support                         */
/*  1.6  |  2012-04-02  |  JP  |  Added support for large shared EEPROM       */
/*  1.7  |  2012-07-13  |  JP  |  Fixed problems on little-endian CPUs        */
/*  1.8  |  2012-09-27  |  JP  |  Configurable initial delay                  */
/*  1.9  |  2013-09-30  |  MAS |  SPI S/N removed, added command to readout   */
/*       |              |      |  SHA1 programming checksum ('c'/'C')         */
/*       |              |      |  Renamed startup boot message                */
/*  1.10 |  2013-12-09  |  MAS |  Flash sector/page size configurable         */
/*       |              |      |  'i'/'I' prints info about flash contents    */
/*  1.11 |  2014-04-15  |  MAS |  't'/'T' toggles flash protection bits       */
/*  1.12 |  2014-04-22  |  JP  |  SPI flash write access related constants    */
/*  1.20 |  2014-07-28  |  JP  |  Block index extended to 16 bits, support    */
/*       |              |      |  for SPI 4B address mode                     */
/*  1.21 |  2014-08-04  |  JP  |  Support for Zynq PS UART                    */
/*  1.22 |  2017-02-27  |  AZ  |  Fixed SPI buffers cleanup                   */
/*  1.23 |  2019-08-21  |  JP  |  Conditional use of custom_regs              */
/*  1.24 |  2021-08-21  |  JP  |  Possibility to define SDRAM base address on */
/*       |              |      |  command line (-D SDRAM=...)                 */
/*  1.25 |  2022-07-27  |  JP  |  The sdram_main defined locally in main()    */
/******************************************************************************/

#include "boot.h"


// ---- Print string to std_out ------------------------------------------------
//
void print_str(char *string)
{
    while (*string != 0)
        xuart_send(*string++);
}


// ---- Print hexadecimal number to std_out ------------------------------------
//
void print_hex(u32 data, int digits)
{
    u8 ch;
    int i;

    for (i = digits - 1; i >= 0; i--)
    {
        ch = (u8)((data >> (i * 4)) & 0x0F) + '0';
        if (ch > '9')
            ch += 'A' - '9' - 1;
        xuart_send(ch);
    }
}


#ifndef __PLATFORM_FLASH__
// ---- Print hexadecimal number to std_out in reversed byte order -------------
//
void print_hex_rev(u32 data, int digits)
{
    u8 ch;
    int i;

    for (i = 0; i < digits; i++)
    {
        ch = (u8)((data >> ((i ^ 1) * 4)) & 0x0F) + '0';
        if (ch > '9')
            ch += 'A' - '9' - 1;
        xuart_send(ch);
    }
}
#endif


// ---- Very simple SDRAM test -------------------------------------------------
//
int sdram_test(u32 *addr, u32 len)
{
    u32 i, pat;

    // Write patterns
    pat = 1;
    for (i = 0; i < len; i++)
    {
        addr[i] = pat;
        if ((pat <<= 1) == 0)
            pat = 1;
    }

    // Check patterns
    pat = 1;
    for (i = 0; i < len; i++)
    {
        if (addr[i] != pat)
            return 1;
        if ((pat <<= 1) == 0)
            pat = 1;
    }

    // No error
    return 0;
}


// ---- Main program -----------------------------------------------------------
//
int main()
{
    int (*sdram_main)(void);
    u32 len = 0;
    u32 sum = 0;
    u8  key;

    // Initialization
    gige_clk_freq  = 100000000; // 83333333;
    gige_tocnt_div = 99999;     // 83332;
    gige_i2c_csr   = 249;       // 51;
    sdram_main     = (void *)SDRAM;

    // Enter the 4B address mode of the SPI flash
#ifdef __FLASH_4B_ADDRESS__
    flash_enter4b();
#endif

    // Flash write protection
    // (at least one protection bit must be set, otherwise renew the protection)
    if ((flash_getstat() & WR_DISABLE) == 0)
        flash_setstat(WR_DISABLE);

    // Print header and perform start-up tests
    print_str("\r\n\r\nS2I GigE Vision bootloader, v1.25 (" __DATE__ ", " __TIME__ ")\r\n");
//  print_str("RAM @ 0x"); print_hex(SDRAM, 8); print_str("\r\n");
    if (sdram_test((u32 *)SDRAM, 0x00040000))
    {
        print_str("SDRAM failed!\r\n");
        while (1) {};
    }
    if (!(gige_spi_gcsr & 0x80000000))
    {
        print_str("SPI failed!\r\n");
        while (1) {};
    }

    // Clear SPI buffers
    for (len = 0; len < 256; len++)
    {
        gige_spi_wbuf[len] = 0;
        gige_spi_rbuf[len] = 0;
    }
    len = 0;

    // Wait for keypress to enter command prompt
    // DELAY ~= (12 * N) * (100 / f) [ms]
    // where N is content of the EEPROM[0x90]
    //       f is actual system clock frequency in MHz
    key = eeprom_read_byte(0x90);
    if (key == 0) key = 0xFF;
    len        = BOOT_DELAY;
    gige_tocnt = (u32)key;
    while (xuart_empty() && len)
    {
        if (!(gige_tocnt))
        {
            gige_tocnt = (u32)key;
            len--;
            print_str(".");
        }
    }

    // Boot the application
    if (!len)
    {
#ifndef __PLATFORM_FLASH__
        // Boot from SPI flash (CANCam-GigE)
        print_str(" booting from spi flash\r\n");
        if (!cmd_load(FLASH_APPLICATION, MAX_APPLICATION, IDX_APPLICATION, &len, &sum))
        {
            gige_gcsr |= 0x80000000;    // Set 'boot finished' status
            sdram_main();
        }
#else
        // Boot from Xilinx platform flash (CANCam-GigE/PtP)
        print_str(" booting from platform flash\r\n");
        if (!cmd_load_xcf())
        {
            gige_gcsr |= 0x80000000;    // Set 'boot finished' status
            sdram_main();
        }
#endif
        gige_gcsr |= 0x40000000;        // Set 'boot failed' status
    }

    // Clean up
#ifdef CUSTOM_REGS
    if (custom_regs[0] == 0x0000000A)
        custom_regs[1] = 0x00000001;
#endif
    while (!xuart_empty())
        xuart_recv();
    len = 0;

    // Command loop
    while (1)
    {
        print_str("\r\nboot> ");
        key = xuart_recv();
        switch (key)
        {
            // Read SHA1 Dongle Checksum
            case 'c':
            case 'C':
                {
                    cmd_checksum();
                    break;
                }
            
            // Upload file over serial line
            case 'u':
            case 'U':
                {
                    print_str("upload\r\n");
                    cmd_upload(2000, &len, &sum);
                    break;
                }

            // Download file over serial line
            //case 'd':
            //case 'D':
            //    {
            //        print_str("download");
            //        cmd_download(len);
            //        break;
            //    }

            // Load data from flash
            case 'l':
            case 'L':
                {
                    print_str("load ");
                    key = xuart_recv();
                    switch (key)
                    {
                        // Primary bitstream
                        case 'b':
                        case 'B':
                            {
                                print_str("bitstream\r\n");
                                cmd_load(FLASH_BITSTREAM, MAX_BITSTREAM, IDX_BITSTREAM, &len, &sum);
                                break;
                            }
                        // Secondary bitstream
                        case 's':
                        case 'S':
                            {
                                print_str("secondary bitstream\r\n");
                                cmd_load(FLASH_SEC_BITSTREAM, MAX_SEC_BITSTREAM, IDX_SEC_BITSTREAM, &len, &sum);
                                break;
                            }
                        // XML file
                        case 'x':
                        case 'X':
                            {
                                print_str("xml file\r\n");
                                cmd_load(FLASH_XML, MAX_XML, IDX_XML, &len, &sum);
                                break;
                            }
                        // Application
                        case 'a':
                        case 'A':
                            {
                                print_str("application\r\n");
                                cmd_load(FLASH_APPLICATION, MAX_APPLICATION, IDX_APPLICATION, &len, &sum);
                                break;
                            }
                        // Configuration EEPROM
                        case 'e':
                        case 'E':
                            {
#ifdef __LARGE_EEPROM__
                                print_str("eeprom ");
                                key = xuart_recv();
                                if ((key >= '0') && (key <= '7'))
                                {
                                    xuart_send(key);
                                    print_str("\r\n");
                                    eeprom_load(&len, &sum, key - '0');
                                }
#else
                                print_str("eeprom\r\n");
                                eeprom_load(&len, &sum);
#endif
                                break;
                            }
                    }
                    break;
                }

            // Save data to flash
            case 's':
            case 'S':
                {
                    print_str("save ");
                    key = xuart_recv();
                    switch (key)
                    {
                        // Primary bitstream
                        case 'b':
                        case 'B':
                            {
                                print_str("bitstream\r\n");
                                cmd_save(FLASH_BITSTREAM, MAX_BITSTREAM, IDX_BITSTREAM, len, sum);
                                break;
                            }
                        // Secondary bitstream
                        case 's':
                        case 'S':
                            {
                                print_str("secondary bitstream\r\n");
                                cmd_save(FLASH_SEC_BITSTREAM, MAX_SEC_BITSTREAM, IDX_SEC_BITSTREAM, len, sum);
                                break;
                            }
                        // XML file
                        case 'x':
                        case 'X':
                            {
                                print_str("xml file\r\n");
                                cmd_save(FLASH_XML, MAX_XML, IDX_XML, len, sum);
                                break;
                            }
                        // Application
                        case 'a':
                        case 'A':
                            {
                                print_str("application\r\n");
                                cmd_save(FLASH_APPLICATION, MAX_APPLICATION, IDX_APPLICATION, len, sum);
                                break;
                            }
                        // Configuration EEPROM
                        case 'e':
                        case 'E':
                            {
#ifdef __LARGE_EEPROM__
                                print_str("eeprom ");
                                key = xuart_recv();
                                if ((key >= '0') && (key <= '7'))
                                {
                                    xuart_send(key);
                                    print_str("\r\n");
                                    eeprom_save(len, sum, key - '0');
                                }
#else
                                print_str("eeprom\r\n");
                                eeprom_save(len, sum);
#endif
                                break;
                            }
                    }
                    break;
                }

            // Run application in SDRAM
            case 'r':
            case 'R':
                {
                    print_str("run\r\n");
                    sdram_main();
                    break;
                }

            // Print info about flash contents
            case 'i':
            case 'I':
                {
                    print_str("info\r\n");
                    cmd_info();
                    break;
                }

            // Toggle FLASH protection bits
            case 't':
            case 'T':
                {                   
                    if (flash_getstat())
                        flash_setstat(WR_ENABLE);
                    else
                        flash_setstat(WR_DISABLE);
                      
                    print_str("toggle flash protection\r\n");
                    print_str("  new stat:  ");
                    print_hex(flash_getstat(), 2);
                    break;
                }

            // Debug
            //case ' ':
            //    {
            //        print_str("debug");
            //        break;
            //    }

            // Read flash serial number
            //case 'n':
            //case 'N':
            //    {
            //        print_str("number\r\n");
            //        cmd_sernum();
            //        break;
            //    }

            // Read evaluation control register
            //case 'e':
            //case 'E':
            //    {
            //        print_str("evaluation\r\n");
            //        print_str("      spi:   0x");
            //        print_hex(gige_spi_gcsr, 8);
            //        //print_str(", gcsr: 0x");
            //        //print_hex(gige_gcsr, 8);
            //        break;
            //    }

            // Read/write FLASH protection bits
            //case 'p':
            //case 'P':
            //    {
            //        print_str("protect\r\n");
            //        print_str("      stat:  ");
            //        print_hex(flash_getstat(), 2);
            //        break;
            //    }

            // Undefined command
            default:
                {
                    break;
                }
        }
    }

    // Never reached exit
    return 0;
}
