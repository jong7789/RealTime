/******************************************************************************/
/*  GigE Vision Bootloader                                                    */
/*----------------------------------------------------------------------------*/
/*    File :  commands.c                                                      */
/*    Date :  2014-08-04                                                      */
/*     Rev :  0.7                                                             */
/*  Author :  JP                                                              */
/*----------------------------------------------------------------------------*/
/*  Command execution functions                                               */
/*----------------------------------------------------------------------------*/
/*  0.1  |  2008-03-07  |  JP  |  Initial release                             */
/*  0.2  |  2008-03-18  |  JP  |  Upload uses XMODEM protocol now             */
/*  0.3  |  2009-02-03  |  JP  |  Extended the S/N output                     */
/*  0.4  |  2013-12-09  |  MAS |  Table info output added                     */
/*  0.5  |  2014-04-22  |  JP  |  SPI flash write access related constants    */
/*  0.6  |  2014-07-28  |  JP  |  Block index extended to 16 bits             */
/*  0.7  |  2014-08-04  |  JP  |  Support for Zynq PS UART                    */
/******************************************************************************/

#include "boot.h"


// ---- XMODEM control characters ----------------------------------------------
//
#define SOH 0x01
#define EOT 0x04
#define ACK 0x06
#define NAK 0x15


// ---- Receive byte from serial line with timeout -----------------------------
//
int rcv_byte(u32 timeout, u8 *byte)
{
    gige_tocnt = timeout;
    while (gige_tocnt)
    {
        if (!xuart_empty())
        {
            *byte = xuart_recv();
            return 0;
        }
    }
    return 1;
}


// ---- Receive single XMODEM packet -------------------------------------------
//
int xmodem_rcv_packet(volatile u8 *buffer)
{
    u8 ch, i, pktnum, sum = 0;

    // Start of header
    if (rcv_byte(10000, &ch))
        return 2;
    if (ch == EOT)
        return -1;
    if (ch != SOH)
        return 1;

    // Block number
    if (rcv_byte(7000, &pktnum))
        return 3;
    if (rcv_byte(7000, &ch))
        return 3;
    if (pktnum != (255 - ch))
        return 4;

    // Packet data
    for (i = 0; i < 128; i++)
    {
        if (rcv_byte(7000, &ch))
            return 3;
        buffer[i] = ch;
        sum      += ch;
    }

    // Checksum
    if (rcv_byte(7000, &ch))
        return 3;
    if (ch != sum)
        return 5;

    return 0;
}


// ---- Upload file over serial line -------------------------------------------
//
void cmd_upload(__attribute__((unused)) u32 timeout, u32 *len, u32 *sum)
{
    volatile u8 *mem = (u8 *)SDRAM;
    int err, retries = 0;
    u32 i;

    // Clear receive buffer and start Xmodem transmission
    if (!xuart_empty())
        xuart_recv();
    do {
        xuart_send(NAK);
        gige_tocnt = 1000;
        while (gige_tocnt && xuart_empty()) {};
    } while (xuart_empty());

    // Receive data and store them to SDRAM
    do {
        err = xmodem_rcv_packet(mem);
        switch (err)
        {
            case -1:    xuart_send(ACK);
                        break;
            case  0:    mem += 128;
                        xuart_send(ACK);
                        break;
            case  1:    break;
            default:    xuart_send(NAK);
                        retries++;
                        break;
        }
    } while ((err != -1) && (retries < 10));

    // Calculate checksum
    *len = (u32)mem - SDRAM;
    *sum = 0;
    mem  = (u8 *)SDRAM;
    for (i = 0; i < *len; i++)
        *sum += mem[i];

    // Delay due to crappy HyperTerminal
    gige_tocnt = 1000;
    while (gige_tocnt) {};

    // Print data length and checksum
    if (retries < 10)
    {
        print_str("\r\n      bytes: 0x");
        print_hex(*len, 8);
        print_str("\r\n      cksum: 0x");
        print_hex(*sum, 8);
    }
    else
    {
        print_str("\r\n      error");
    }

    return;
}


// ---- Download file over serial line -----------------------------------------
//
//void cmd_download(u32 len)
//{
//    return;
//}


#ifdef __PLATFORM_FLASH__
// ---- Load application from platform flash -----------------------------------
//
int cmd_load_xcf(void)
{
    u32 *sdram = (u32 *)SDRAM;
    u32 i = 0, sum = 0;

    // Read data from flash
    do {
        gige_tocnt = 10;
        while ((!(custom_regs[1] & 0x80000000)) && (gige_tocnt)) {};
        if (gige_tocnt)
        {
            sdram[i++] = custom_regs[2];
            sum       += sdram[i];
        }
    } while (gige_tocnt);

    // Assert config_done signal
    custom_regs[1] = 0x00000001;

    // Print result and exit
    if (i)
    {
        gige_spi_door = 0x444F4F52;
        print_str("      bytes: 0x");
        print_hex(i * 4, 8);
        print_str("\r\n      cksum: 0x");
        print_hex(sum, 8);
        return 0;
    }
    else
    {
        print_str("      no data");
        return 1;
    }
}
#endif


// ---- Load data from flash to SDRAM ------------------------------------------
//
int cmd_load(u16 block, u32 maxlen, u8 idx, u32 *len, u32 *sum)
{
    u32 i, tmp;
    u32 *mem = (u32 *)SDRAM;
    *sum = 0;

    // Retrieve data parameters
    flash_getpar(idx, &i, &tmp);
    *len = i;
    if ((*len == 0) || (*len > maxlen))
    {
        *len = 0;
        print_str("      no data");
        return 1;
    }

    // Read data from flash
    for (i = 0; (i * SECTOR_SIZE) < *len; i++)
        *sum += flash_read(block + (u16)i,
                           &mem,
                           minimum(*len - (i * SECTOR_SIZE), SECTOR_SIZE));

    // Print result
    print_str("      bytes: 0x");
    print_hex(*len, 8);
    print_str("\r\n      cksum: 0x");
    print_hex(*sum, 8);
    if (tmp == *sum)
    {
        print_str(" (ok)");
        return 0;
    }
    else
    {
        print_str(" (error)");
        return 2;
    }
}


// ---- Save data from SDRAM to flash ------------------------------------------
//
void cmd_save(u16 block, u32 maxlen, u8 idx, u32 len, u32 sum)
{
    u32 i, tmp = 0;

    // Check data length
    if (len == 0)
    {
        print_str("      no data");
        return;
    }
    if (len > maxlen)
    {
        print_str("      too much data");
        return;
    }

    // Enable flash write access
    flash_setstat(WR_ENABLE);

    // Write data into flash
    for (i = 0; (i * SECTOR_SIZE) < len; i++)
        flash_write(block + (u16)i,
                    (u32 *)(SDRAM + (i * SECTOR_SIZE)),
                    minimum(len - (i * SECTOR_SIZE), SECTOR_SIZE));

    // Store data parameters
    flash_setpar(idx, len, sum);

    // Flash write protection
    flash_setstat(WR_DISABLE);

    // Calculate checksum from flash contents
    for (i = 0; (i * SECTOR_SIZE) < len; i++)
        tmp += flash_sum(block + (u16)i, minimum(len - (i * SECTOR_SIZE), SECTOR_SIZE));

    // Print result
    print_str("      bytes: 0x");
    print_hex(len, 8);
    print_str("\r\n      cksum: 0x");
    print_hex(tmp, 8);
    if (tmp == sum)
        print_str(" (ok)");
    else
        print_str(" (error)");

    return;
}


// ---- Read sha1 checksum -----------------------------------------------------
//
void cmd_checksum(void)
{
    u8 num1, num2;
    // Read ckecksum
    num1 = sha1_read_byte(0x96); 
    num2 = sha1_read_byte(0x97); 
    
    // Print result
    print_str("Checksum: 0x");
    print_hex(num1, 2);
    print_hex(num2, 2);

    return;
}


// ---- Print info about flash contents ----------------------------------------
//
void cmd_info()
{
    int i;
    u32 addr, len, sum;

    print_str("      num    start     length    checksum ");
//            "      00     12345678  12345678  12345678 "
    for (i = 0; i < PARTITIONS; i++)
    {
        switch (i)
        {
          case IDX_BITSTREAM     : addr = (u32)(FLASH_BITSTREAM * SECTOR_SIZE); break;
          case IDX_SEC_BITSTREAM : addr = (u32)(FLASH_SEC_BITSTREAM * SECTOR_SIZE); break;
          case IDX_PARAMETERS    : addr = (u32)(FLASH_PARAMETERS * SECTOR_SIZE); break;
          case IDX_XML           : addr = (u32)(FLASH_XML * SECTOR_SIZE); break;
          case IDX_APPLICATION   : addr = (u32)(FLASH_APPLICATION * SECTOR_SIZE); break;
          default                : addr = 0xFFFFFFFF; break;
        }  
        flash_getpar(i, &len, &sum);
        
        // Partition number
        print_str("\r\n      ");
        print_hex(i, 2);
        print_str(":    ");
        // Start address
        print_hex(addr, 8);
        print_str("  ");
        // Block size
        print_hex(len, 8);
        print_str("  ");
        // Check sum
        print_hex(sum, 8);
        print_str("  ");
    }

    return;
}
