/******************************************************************************/
/*  GigE Vision Bootloader                                                    */
/*----------------------------------------------------------------------------*/
/*    File :  boot.h                                                          */
/*    Date :  2022-07-27                                                      */
/*     Rev :  0.16                                                            */
/*  Author :  JP                                                              */
/*----------------------------------------------------------------------------*/
/*  Declarations, definitions, and function prototypes                        */
/*----------------------------------------------------------------------------*/
/*  0.1  |  2008-03-07  |  JP  |  Initial release                             */
/*  0.2  |  2009-11-18  |  JP  |  SPI flash organization can be specified by  */
/*       |              |      |  compiler command line defines (-D x=y)      */
/*  0.3  |  2010-04-14  |  JP  |  Modified MPMC memory definition macros      */
/*  0.4  |  2012-04-02  |  JP  |  Added support for large shared EEPROM       */
/*  0.5  |  2012-07-10  |  JP  |  Support for Spartan-6 AXI based CPU system  */
/*  0.6  |  2012-07-13  |  JP  |  Macro for endianness of the current CPU     */
/*       |              |      |  according to the XPAR_MICROBLAZE_ENDIANNESS */
/*  0.7  |  2012-09-27  |  JP  |  Removed BOOT_TICK constant                  */
/*  0.8  |  2013-01-09  |  JP  |  Support for Kintex-7 AXI based CPU system   */
/*  0.9  |  2013-12-09  |  MAS |  SPI flash sector/page size can be specified */
/*       |              |      |  by compiler options                         */
/*  0.10 |  2014-04-22  |  JP  |  SPI flash write access related constants    */
/*  0.11 |  2014-07-28  |  JP  |  Block index extended to 16 bits, support    */
/*       |              |      |  for SPI 4B address mode                     */
/*  0.12 |  2014-08-04  |  JP  |  Support for Zynq PS UART                    */
/*  0.13 |  2014-11-20  |  JP  |  Fixed endianness macro for newer SDK/EDK    */
/*  0.14 |  2019-08-21  |  JP  |  Conditional CUSTOM_REGS and GIGE_REGS       */
/*  0.15 |  2021-05-14  |  JP  |  Removed SDRAM_LEN macro, conditional SDRAM  */
/*       |              |      |  base address definition                     */
/*  0.16 |  2022-07-27  |  JP  |  Removed sdram_main declaration as it seems  */
/*       |              |      |  to become definition in new GCC versions    */
/******************************************************************************/

#ifndef _BOOT_H_
#define _BOOT_H_


// ---- Common includes --------------------------------------------------------

#include <xparameters.h>
#include <xil_types.h>


// ---- Generic constants ------------------------------------------------------

// Initial delay before boot in ticks, length of tick in ms
#define BOOT_DELAY      12
// BOOT_TICK constant is replaced by contents of the EEPROM[0x90]
//#define BOOT_TICK       300

// UART base address
#if defined XPAR_UARTLITE_0_BASEADDR
#   define XUART        XPAR_UARTLITE_0_BASEADDR
#   define XUART_LITE
#elif defined XPAR_XUARTPS_0_BASEADDR
#   define XUART        XPAR_XUARTPS_0_BASEADDR
#   define XUART_PS
#endif

// SDRAM base address
#ifndef SDRAM
#   if defined XPAR_XMPMC_NUM_INSTANCES
#      define SDRAM XPAR_SDRAM_0_MPMC_BASEADDR
#   elif defined XPAR_XS6DDR_NUM_INSTANCES
#      define SDRAM XPAR_SDRAM_0_S0_AXI_BASEADDR
#   elif defined XPAR_XAXI_7SDDR_NUM_INSTANCES
#      define SDRAM XPAR_SDRAM_0_S_AXI_BASEADDR
#   elif defined XPAR_PS7_DDR_0_S_AXI_BASEADDR
#      define SDRAM XPAR_PS7_DDR_0_S_AXI_BASEADDR
#   else
#      define SDRAM XPAR_SDRAM_0_BASEADDR
#   endif
#endif

// Endianness of the CPU
#if defined XPAR_MICROBLAZE_ENDIANNESS
#   if XPAR_MICROBLAZE_ENDIANNESS == 0
#       define BIG_ENDIAN
#   else
#       define LITTLE_ENDIAN
#   endif
#elif defined XPAR_CPU_CORTEXA9_0_CPU_CLK_FREQ_HZ
#   define LITTLE_ENDIAN
#else
#   define BIG_ENDIAN
#endif


// ---- Specific includes ------------------------------------------------------

// Include UART-specific header
#if defined XUART_LITE
#   include <xuartlite_l.h>
#elif defined XUART_PS
#   include <xuartps_hw.h>
#endif


// ---- Hardware registers -----------------------------------------------------

// Control register banks
#ifndef GIGE_REGS
#   define GIGE_REGS    XPAR_EPC_0_PRH0_BASEADDR
#endif

// Common registers
#define gige_gcsr       (*(volatile u32 *)(GIGE_REGS + 0xC000))
#define gige_clk_freq   (*(volatile u32 *)(GIGE_REGS + 0xC008))
#define gige_tocnt_div  (*(volatile u32 *)(GIGE_REGS + 0xC014))
#define gige_tocnt      (*(volatile u32 *)(GIGE_REGS + 0xC018))

// I2C registers
#define gige_i2c_cmd    (*(volatile u32 *)(GIGE_REGS + 0xE000))
#define gige_i2c_csr    (*(volatile u32 *)(GIGE_REGS + 0xE004))
#define gige_i2c_dr     (*(volatile u32 *)(GIGE_REGS + 0xE008))

// SPI registers
#define gige_spi_gcsr   (*(volatile u32 *)(GIGE_REGS + 0xF000))
#define gige_spi_addr   (*(volatile u32 *)(GIGE_REGS + 0xF004))
#define gige_spi_sn_h   (*(volatile u32 *)(GIGE_REGS + 0xF008))
#define gige_spi_sn_l   (*(volatile u32 *)(GIGE_REGS + 0xF00C))
#define gige_spi_door   (*(volatile u32 *)(GIGE_REGS + 0xF010))
#define gige_spi_wbuf   ( (volatile u32 *)(GIGE_REGS + 0xF800))
#define gige_spi_rbuf   ( (volatile u32 *)(GIGE_REGS + 0xFC00))

// Custom registers
#ifndef CUSTOM_REGS
#   ifdef XPAR_EPC_0_PRH1_BASEADDR
#       define CUSTOM_REGS  XPAR_EPC_0_PRH1_BASEADDR
#   endif
#endif
#ifdef CUSTOM_REGS
#   define custom_regs  ( (volatile u32 *)(CUSTOM_REGS + 0x0000))
#endif


// ---- SPI constants ----------------------------------------------------------

// Value to disable write access to all flash partitions/sectors
// Consult SPI flash datasheet to check the correct value!
#define WR_DISABLE          0x7C
#define WR_ENABLE           0x00

// Number of SPI flash partitions
#define PARTITIONS          6

// SPI flash memory parameter indices
#define IDX_BITSTREAM       0
#define IDX_SEC_BITSTREAM   1
#define IDX_PARAMETERS      2
#define IDX_XML             3
#define IDX_RESERVED        4
#define IDX_APPLICATION     5

// SPI chip parameters
#ifndef _SECTOR_SIZE_
#   define SECTOR_SIZE      65536
#else
#   define SECTOR_SIZE      _SECTOR_SIZE_
#endif

#ifndef _PAGE_SIZE_
#   define PAGE_SIZE        256
#else
#   define PAGE_SIZE        _PAGE_SIZE_
#endif

// SPI flash memory partitioning (in Sectors, e.g. 64 or 256kB blocks)
// Starting Sector of each partition
#ifndef _OFFSET_BIT_
#   define FLASH_BITSTREAM      0x0000
#else
#   define FLASH_BITSTREAM      _OFFSET_BIT_
#endif
#ifndef _OFFSET_SEC_
#   define FLASH_SEC_BITSTREAM  0x0010
#else
#   define FLASH_SEC_BITSTREAM  _OFFSET_SEC_
#endif
#ifndef _OFFSET_TAB_
#   define FLASH_PARAMETERS     0x0020
#else
#   define FLASH_PARAMETERS     _OFFSET_TAB_
#endif
#ifndef _OFFSET_XML_
#   define FLASH_XML            0x0021
#else
#   define FLASH_XML            _OFFSET_XML_
#endif
#ifndef _OFFSET_APP_
#   define FLASH_APPLICATION    0x0040
#else
#   define FLASH_APPLICATION    _OFFSET_APP_
#endif

// SPI flash memory maximum partition sizes
#ifndef _MAX_BIT_
#   define MAX_BITSTREAM        0x100000
#else
#   define MAX_BITSTREAM        _MAX_BIT_
#endif
#ifndef _MAX_SEC_
#   define MAX_SEC_BITSTREAM    0x100000
#else
#   define MAX_SEC_BITSTREAM    _MAX_SEC_
#endif
#ifndef _MAX_TAB_
#   define MAX_PARAMETERS       0x010000
#else
#   define MAX_PARAMETERS       _MAX_TAB_
#endif
#ifndef _MAX_XML_
#   define MAX_XML              0x0F0000
#else
#   define MAX_XML              _MAX_XML_
#endif
#ifndef _MAX_APP_
#   define MAX_APPLICATION      0x400000
#else
#   define MAX_APPLICATION      _MAX_APP_
#endif


// ---- EEPROM constants -------------------------------------------------------

// Memory size
#define EEPROM_LEN          8192

// Default parameters
#define DEFAULT_MAC         0x0000000C6B00012CULL
#define DEFAULT_PORT        3956
#define GIGE_SUPIPCONFIG    0x00000007


// ---- Macros -----------------------------------------------------------------

// Get minimum of two values
#define minimum(a, b)   (a < b ? a : b)

// Support for EDK 12 and above
#ifndef XUartLite_mIsReceiveEmpty
#   define XUartLite_mIsReceiveEmpty XUartLite_IsReceiveEmpty
#endif

// Send one byte to UART
#if defined XUART_LITE
#   define xuart_send(ch)   XUartLite_SendByte((XUART), (ch))
#elif defined XUART_PS
#   define xuart_send(ch)   XUartPs_SendByte((XUART), (ch))
#endif

// Receive one byte from UART
#if defined XUART_LITE
#   define xuart_recv()     XUartLite_RecvByte(XUART)
#elif defined XUART_PS
#   define xuart_recv()     XUartPs_RecvByte(XUART)
#endif

// Check if receive buffer is empty
#if defined XUART_LITE
#   define xuart_empty()    XUartLite_mIsReceiveEmpty(XUART)
#elif defined XUART_PS
#   define xuart_empty()    (!XUartPs_IsReceiveData(XUART))
#endif


// ---- Function prototypes ----------------------------------------------------

// General purpose functions
void print_str(char *string);
void print_hex(u32 data, int digits);
#ifndef __PLATFORM_FLASH__
void print_hex_rev(u32 data, int digits);
#endif
int  sdram_test(u32 *addr, u32 len);

// SPI flash memory functions
u8   flash_getstat();
void flash_setstat(u8 val);
void flash_getpar(u8 idx, u32 *len, u32 *sum);
void flash_setpar(u8 idx, u32 len, u32 sum);
void flash_write(u16 block, u32 *addr, u32 len);
u32  flash_read(u16 block, u32 **addr, u32 len);
u32  flash_sum(u16 block, u32 len);
void flash_enter4b();
void flash_exit4b();

// Command execution functions
void cmd_upload(u32 timeout, u32 *len, u32 *sum);
void cmd_download(u32 len);
#ifdef __PLATFORM_FLASH__
int  cmd_load_xcf(void);
#endif
int  cmd_load(u16 block, u32 maxlen, u8 idx, u32 *len, u32 *sum);
void cmd_save(u16 block, u32 maxlen, u8 idx, u32 len, u32 sum);
void cmd_sernum(void);
void cmd_checksum(void);
void cmd_info();

// I2C EEPROM functions
u8   sha1_read_byte    (u8  address);
u8   eeprom_read_byte  (u16 address);
void eeprom_write_dword(u16 address, u32 value);
#ifdef __LARGE_EEPROM__
void eeprom_load(u32 *len, u32 *sum, u8 offs);
void eeprom_save(u32 len, u32 sum, u8 offs);
#else
void eeprom_load(u32 *len, u32 *sum);
void eeprom_save(u32 len, u32 sum);
#endif

#endif
