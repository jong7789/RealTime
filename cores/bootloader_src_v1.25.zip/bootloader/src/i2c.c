/******************************************************************************/
/*  GigE Vision Bootloader                                                    */
/*----------------------------------------------------------------------------*/
/*    File :  flash.c                                                         */
/*    Date :  2012-07-13                                                      */
/*     Rev :  0.4                                                             */
/*  Author :  JP                                                              */
/*----------------------------------------------------------------------------*/
/*  I2C EEPROM read and write functions                                       */
/*----------------------------------------------------------------------------*/
/*  0.1  |  2008-03-07  |  JP  |  Initial release                             */
/*  0.2  |  2009-11-18  |  JP  |  EEPROM hw address can be defined externally */
/*  0.3  |  2012-04-02  |  JP  |  Added support for large shared EEPROM       */
/*  0.4  |  2012-07-13  |  JP  |  EEPROM write according to CPU endianness    */
/******************************************************************************/

#include "boot.h"


// ---- Private constants ------------------------------------------------------

// Device address of the 24C64 I2C EEPROM
#ifdef _EE_ADDR_
#   define I2C_DEV_EEPROM   (_EE_ADDR_ & 0xFE)
#else
#   define I2C_DEV_EEPROM   0xA0
#endif

// Device address of the 28CN01 I2C SHA1-EEPROM
#define I2C_DEV_SHA1        0xAA

// Maximum write time of the EEPROM in milliseconds
#define EEPROM_WRITE_DELAY  10

// EEPROM memory map
#define EE_MAC              0x0000
#define EE_IPCFG            0x0007
#define EE_IP               0x0014
#define EE_NETMASK          0x0024
#define EE_GATEWAY          0x0034
#define EE_GVCP_PORT        0x003A
#define EE_USER_NAME        0x0040
#define EE_XML_1            0x1C00
#define EE_XML_2            0x1E00
#define EE_LENGTH           0x2000

// Register "gige_i2c_cmd" bits
#define I2C_CMD_ABYTES      0x30000000
#define I2C_CMD_DBYTES      0x07000000
#define I2C_CMD_DEVICE      0x00FE0000
#define I2C_CMD_RNW         0x00010000
#define I2C_CMD_ADDR        0x0000FFFF

// Register "gige_i2c_csr" bits
#define I2C_CSR_READY       0x80000000
#define I2C_CSR_ERROR       0x40000000
#define I2C_CSR_CLKDIV      0x0000FFFF

// I2C macros
#define I2C_ERR             (gige_i2c_csr & I2C_CSR_ERROR)


// ---- Write byte to EEPROM ---------------------------------------------------
//
/*void eeprom_write_byte(u16 address, u8 value)
{
    gige_i2c_dr  = (u32)value;                              // Data to write
    gige_i2c_cmd = 0x21000000 |                             // I2C write command
                   ((I2C_DEV_EEPROM << 16) & I2C_CMD_DEVICE) |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish
    gige_tocnt = EEPROM_WRITE_DELAY;
    while (gige_tocnt) {};                                  // Write time delay

    return;
}*/


// ---- Read byte from EEPROM --------------------------------------------------
//
u8 eeprom_read_byte(u16 address)
{
    gige_i2c_cmd = 0x21000000 |                             // I2C read command
                   (I2C_DEV_EEPROM << 16) |
                   I2C_CMD_RNW |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish

    return (u8)(gige_i2c_dr & 0x000000FF);                  // Read value
}


// ---- Read byte from DS28CN01 ------------------------------------------------
//
u8 sha1_read_byte(u8 address)
{
    gige_i2c_cmd = 0x11000000 |                             // I2C read command
                   (I2C_DEV_SHA1 << 16) |
                   I2C_CMD_RNW |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish

    return (u8)(gige_i2c_dr & 0x000000FF);                  // Read value
}


// ---- Write word to EEPROM ---------------------------------------------------
//
/*void eeprom_write_word(u16 address, u16 value)
{
    gige_i2c_dr  = (u32)value;                              // Data to write
    gige_i2c_cmd = 0x22000000 |                             // I2C write command
                   ((I2C_DEV_EEPROM << 16) & I2C_CMD_DEVICE) |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish
    gige_tocnt = EEPROM_WRITE_DELAY;
    while (gige_tocnt) {};                                  // Write time delay

    return;
}*/


// ---- Read word from EEPROM --------------------------------------------------
//
/*u16 eeprom_read_word(u16 address)
{
    gige_i2c_cmd = 0x22000000 |                             // I2C read command
                   (I2C_DEV_EEPROM << 16) |
                   I2C_CMD_RNW |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish

    return (u16)(gige_i2c_dr & 0x0000FFFF);                 // Read value
}*/


// ---- Write double-word to EEPROM --------------------------------------------
//
void eeprom_write_dword(u16 address, u32 value)
{
#ifdef LITTLE_ENDIAN
    gige_i2c_dr  = ((value << 24) & 0xFF000000) |           // Little endian data to write
                   ((value <<  8) & 0x00FF0000) |
                   ((value >>  8) & 0x0000FF00) |
                   ((value >> 24) & 0x000000FF);
#else
    gige_i2c_dr  = value;                                   // Big endian data to write
#endif
    gige_i2c_cmd = 0x24000000 |                             // I2C write command
                   ((I2C_DEV_EEPROM << 16) & I2C_CMD_DEVICE) |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish
    gige_tocnt = EEPROM_WRITE_DELAY;
    while (gige_tocnt) {};                                  // Write time delay

    return;
}


// ---- Read double-word from EEPROM -------------------------------------------
//
/*u32 eeprom_read_dword(u16 address)
{
    gige_i2c_cmd = 0x24000000 |                             // I2C read command
                   (I2C_DEV_EEPROM << 16) |
                   I2C_CMD_RNW |
                   (u32)address;
    while (!(gige_i2c_csr & I2C_CSR_READY)) {};             // Wait for finish

    return gige_i2c_dr;                                     // Read value
}*/


// ---- Write string to EEPROM -------------------------------------------------
//
/*int eeprom_write_string(u16 address, int length, u8 *buffer)
{
    int i;

    for (i = 0; i < length; i++)
    {
        eeprom_write_byte(address + i, buffer[i]);
        if (I2C_ERR)
            return i + 1;
    }

    return 0;
}*/


// ---- Read string from EEPROM ------------------------------------------------
//
/*int eeprom_read_string(u16 address, int length, u8 *buffer)
{
    int i;

    for (i = 0; i < length; i++)
    {
        buffer[i] = eeprom_read_byte(address + i);
        if (I2C_ERR)
            return i + 1;
    }

    return 0;
}*/


// ---- Save SDRAM data to EEPROM ----------------------------------------------
//
#ifdef __LARGE_EEPROM__
void eeprom_save(u32 len, u32 sum, u8 offs)
#else
void eeprom_save(u32 len, u32 sum)
#endif
{
    volatile u32 *mem = (u32 *)SDRAM;
    u32 i, tmp = 0;

    // Check data length
    if (len == 0)
    {
        print_str("      no data");
        return;
    }
    if (len > EEPROM_LEN)
    {
        print_str("      too much data");
        return;
    }

    // Write data into EEPROM
    for (i = 0; i < (len / 4); i++)
    {
#ifdef __LARGE_EEPROM__
        eeprom_write_dword((i * 4) + ((u16)offs * 0x2000), mem[i]);
#else
        eeprom_write_dword(i * 4, mem[i]);
#endif
        if (I2C_ERR)
        {
            print_str("      error");
            return;
        }
    }

    // Calculate checksum from EEPROM contents
    for (i = 0; i < len; i++)
    {
#ifdef __LARGE_EEPROM__
        tmp += eeprom_read_byte(i + ((u16)offs * 0x2000));
#else
        tmp += eeprom_read_byte(i);
#endif
        if (I2C_ERR)
        {
            print_str("      error");
            return;
        }
    }

    // Print result
    print_str("      bytes: 0x");
    print_hex(len, 8);
    print_str("\r\n      cksum: 0x");
    print_hex(tmp, 8);
    if (tmp == sum)
        print_str(" (ok)");
    else
        print_str(" (error)");

    return;
}


// ---- Load EEPROM contents into SDRAM ----------------------------------------
//
#ifdef __LARGE_EEPROM__
void eeprom_load(u32 *len, u32 *sum, u8 offs)
#else
void eeprom_load(u32 *len, u32 *sum)
#endif
{
    volatile u8 *mem = (u8 *)SDRAM;
    u32 i;

    *sum = 0;
    *len = EE_LENGTH;

    // Read data from EEPROM
    for (i = 0; i < EE_LENGTH; i++)
    {
#ifdef __LARGE_EEPROM__
        mem[i] = eeprom_read_byte(i + ((u16)offs * 0x2000));
#else
        mem[i] = eeprom_read_byte(i);
#endif
        *sum  += mem[i];
        if (I2C_ERR)
        {
            *len = 0;
            *sum = 0;
            print_str("      error");
            return;
        }
    }

    // Print result
    print_str("      bytes: 0x");
    print_hex(*len, 8);
    print_str("\r\n      cksum: 0x");
    print_hex(*sum, 8);

    return;
}
