# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  #Adding Group
  set Main [ipgui::add_group $IPINST -name "Main" -parent ${Page_0}]
  ipgui::add_param $IPINST -name "ADDR_WIDTH" -parent ${Main}
  ipgui::add_param $IPINST -name "DATA_WIDTH" -parent ${Main} -widget comboBox
  ipgui::add_param $IPINST -name "OUT_WIDTH" -parent ${Main} -widget comboBox
  ipgui::add_param $IPINST -name "BURST_LEN" -parent ${Main} -widget comboBox

  #Adding Group
  set FIFOs [ipgui::add_group $IPINST -name "FIFOs" -parent ${Page_0}]
  ipgui::add_param $IPINST -name "IN_FIFO_SIZE" -parent ${FIFOs} -widget comboBox
  ipgui::add_param $IPINST -name "DESCR_SIZE" -parent ${FIFOs} -widget comboBox

  #Adding Group
  set Features [ipgui::add_group $IPINST -name "Features" -parent ${Page_0}]
  ipgui::add_param $IPINST -name "EN_RESEND" -parent ${Features}
  ipgui::add_param $IPINST -name "EN_STATISTICS" -parent ${Features}
  ipgui::add_param $IPINST -name "EN_DYN_TRAIL" -parent ${Features}

  #Adding Group
  set Notes [ipgui::add_group $IPINST -name "Notes" -parent ${Page_0}]
  ipgui::add_static_text $IPINST -name "NOTE_1" -parent ${Notes} -text {1. AXI data width and burst length must not lead to bursts exceeding 4KB}
  ipgui::add_static_text $IPINST -name "NOTE_2" -parent ${Notes} -text {2. Output data width should be smaller or equal to AXI and input data width}



}

proc update_PARAM_VALUE.ADDR_WIDTH { PARAM_VALUE.ADDR_WIDTH } {
	# Procedure called to update ADDR_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ADDR_WIDTH { PARAM_VALUE.ADDR_WIDTH } {
	# Procedure called to validate ADDR_WIDTH
	return true
}

proc update_PARAM_VALUE.BURST_LEN { PARAM_VALUE.BURST_LEN } {
	# Procedure called to update BURST_LEN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BURST_LEN { PARAM_VALUE.BURST_LEN } {
	# Procedure called to validate BURST_LEN
	return true
}

proc update_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to update DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to validate DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.DESCR_SIZE { PARAM_VALUE.DESCR_SIZE } {
	# Procedure called to update DESCR_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DESCR_SIZE { PARAM_VALUE.DESCR_SIZE } {
	# Procedure called to validate DESCR_SIZE
	return true
}

proc update_PARAM_VALUE.EN_DYN_TRAIL { PARAM_VALUE.EN_DYN_TRAIL } {
	# Procedure called to update EN_DYN_TRAIL when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.EN_DYN_TRAIL { PARAM_VALUE.EN_DYN_TRAIL } {
	# Procedure called to validate EN_DYN_TRAIL
	return true
}

proc update_PARAM_VALUE.EN_RESEND { PARAM_VALUE.EN_RESEND } {
	# Procedure called to update EN_RESEND when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.EN_RESEND { PARAM_VALUE.EN_RESEND } {
	# Procedure called to validate EN_RESEND
	return true
}

proc update_PARAM_VALUE.EN_STATISTICS { PARAM_VALUE.EN_STATISTICS } {
	# Procedure called to update EN_STATISTICS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.EN_STATISTICS { PARAM_VALUE.EN_STATISTICS } {
	# Procedure called to validate EN_STATISTICS
	return true
}

proc update_PARAM_VALUE.IN_FIFO_SIZE { PARAM_VALUE.IN_FIFO_SIZE } {
	# Procedure called to update IN_FIFO_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IN_FIFO_SIZE { PARAM_VALUE.IN_FIFO_SIZE } {
	# Procedure called to validate IN_FIFO_SIZE
	return true
}

proc update_PARAM_VALUE.OUT_WIDTH { PARAM_VALUE.OUT_WIDTH } {
	# Procedure called to update OUT_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.OUT_WIDTH { PARAM_VALUE.OUT_WIDTH } {
	# Procedure called to validate OUT_WIDTH
	return true
}


proc update_MODELPARAM_VALUE.ADDR_WIDTH { MODELPARAM_VALUE.ADDR_WIDTH PARAM_VALUE.ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ADDR_WIDTH}] ${MODELPARAM_VALUE.ADDR_WIDTH}
}

proc update_MODELPARAM_VALUE.DATA_WIDTH { MODELPARAM_VALUE.DATA_WIDTH PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DATA_WIDTH}] ${MODELPARAM_VALUE.DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.OUT_WIDTH { MODELPARAM_VALUE.OUT_WIDTH PARAM_VALUE.OUT_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.OUT_WIDTH}] ${MODELPARAM_VALUE.OUT_WIDTH}
}

proc update_MODELPARAM_VALUE.BURST_LEN { MODELPARAM_VALUE.BURST_LEN PARAM_VALUE.BURST_LEN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BURST_LEN}] ${MODELPARAM_VALUE.BURST_LEN}
}

proc update_MODELPARAM_VALUE.IN_FIFO_SIZE { MODELPARAM_VALUE.IN_FIFO_SIZE PARAM_VALUE.IN_FIFO_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IN_FIFO_SIZE}] ${MODELPARAM_VALUE.IN_FIFO_SIZE}
}

proc update_MODELPARAM_VALUE.DESCR_SIZE { MODELPARAM_VALUE.DESCR_SIZE PARAM_VALUE.DESCR_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DESCR_SIZE}] ${MODELPARAM_VALUE.DESCR_SIZE}
}

proc update_MODELPARAM_VALUE.EN_STATISTICS { MODELPARAM_VALUE.EN_STATISTICS PARAM_VALUE.EN_STATISTICS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.EN_STATISTICS}] ${MODELPARAM_VALUE.EN_STATISTICS}
}

proc update_MODELPARAM_VALUE.EN_RESEND { MODELPARAM_VALUE.EN_RESEND PARAM_VALUE.EN_RESEND } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.EN_RESEND}] ${MODELPARAM_VALUE.EN_RESEND}
}

proc update_MODELPARAM_VALUE.EN_DYN_TRAIL { MODELPARAM_VALUE.EN_DYN_TRAIL PARAM_VALUE.EN_DYN_TRAIL } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.EN_DYN_TRAIL}] ${MODELPARAM_VALUE.EN_DYN_TRAIL}
}

#-------------------------------------------------------------------------------
#  Sensor to Image GmbH
#-------------------------------------------------------------------------------
#  Tcl procedures to validate some parameters of the unified AXI framebuffer IP
#  core. It needs to be appended to the automatically generated XGUI Tcl script
#  in the Vivado IP package.
#
#  NOTE: Appending these procedures to the end of the auto-generated XGUI script
#        exploits a Tcl feature that second procedure declaration replaces the
#        first one. Otherwise regexp based parsing of the original file and
#        replacing the procedures declaration would be needed.
#-------------------------------------------------------------------------------
#  0.1  |  2022-06-29  |  JP  |  Initial release
#  0.2  |  2022-07-20  |  JP  |  Complete XGUI script changed to template with
#       |              |      |  validation procedures only
#-------------------------------------------------------------------------------

# Procedure called to validate the BURST_LEN parameter
proc validate_PARAM_VALUE.BURST_LEN { PARAM_VALUE.BURST_LEN PARAM_VALUE.DATA_WIDTH } {
    set dw [ get_property value ${PARAM_VALUE.DATA_WIDTH} ]
    set bl [ get_property value ${PARAM_VALUE.BURST_LEN} ]
    set burst [ expr {($dw / 8) * $bl} ]
    if {$burst > 4096} {
        set_property errmsg "Burst length $bl exceeds 4KB AXI4 address boundary for $dw b AXI data width." ${PARAM_VALUE.BURST_LEN}
        return false
    } else {
        return true
    }
}

# Procedure called to validate the DATA_WIDTH parameter
proc validate_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH PARAM_VALUE.BURST_LEN } {
    set dw [ get_property value ${PARAM_VALUE.DATA_WIDTH} ]
    set bl [ get_property value ${PARAM_VALUE.BURST_LEN} ]
    set burst [ expr {($dw / 8) * $bl} ]
    if {$burst > 4096} {
        set_property errmsg "AXI data with $dw b for burst length $bl exceeds 4KB AXI4 address boundary." ${PARAM_VALUE.DATA_WIDTH}
        return false
    } else {
        return true
    }
}
